# STRANGER · 건축 외벽·측면 가구·지하 설비 보완 기본 맵 (`STRANGER-Museum-Base`)

퍼즐 전용 오브젝트를 모두 제외한 상태에서 **1F · 2F · B1 전체 13개 방의 외벽·모서리 기둥 구조 보수, 2F 대각선 석재 아치 출입구, 연속 중앙 레드카펫, 측면 3/4 가구 배치, 3연 차단봉, 지하 보일러·수압·고압 전기 설비 구현**을 마친 기본 맵 패키지입니다.

- 전체 및 상세 이미지: [`STRANGER-Overview.png`](STRANGER-Overview.png) · [`STRANGER-13Rooms-Base-Grid.png`](STRANGER-13Rooms-Base-Grid.png) · [`STRANGER-1F-detail.png`](STRANGER-1F-detail.png) · [`STRANGER-2F-detail.png`](STRANGER-2F-detail.png) · [`STRANGER-B1-detail.png`](STRANGER-B1-detail.png) · [`STRANGER-Basement-Access.png`](STRANGER-Basement-Access.png)
- `index.html`을 브라우저/로컬 서버로 열면 캐릭터(`30×50px`, 발밑 판정 `14×8px`)로 13개 방 이동, 문/계단 전환(`E` 키), 충돌 영역을 바로 테스트할 수 있습니다.

---

## 주요 구조·배치 수정 내역

### 1. 건물 외벽 모서리 · 기둥 · 2F 대각선 아치 · 카펫 정합성 (`*-structure.png`)
- **외벽 모서리 & 중간 외벽 기둥 복원**: `1F` 중앙부 `91px` 끊김(`y=1261..1352`) 및 `1F · 2F · B1` 모서리 외벽 결손을 원본 벽체 단면 연장 + 모서리·구획 기둥 캡으로 보수해 외벽 윤곽이 끊기지 않습니다.
- **2F 대각선 문(`archive-door`, `preserve-door`) 석재 아치 전실 재구축**: 어색하게 겹쳐 있던 갈색 회전 박스 2개를 제거하고, 계단식 석재 통로와 단일 호두나무·황동 상인방 아치 포털이 반원 로툰다 석조 벽체와 자연스럽게 이어지도록 재설계했습니다.
- **연속 중앙 레드카펫 동선**: `1F` 중앙 복도는 상단 2F 계단(`y=1016`)부터 나침반 장미 원형 테두리까지 빈틈없이 이어지도록 잇고 아래쪽 어색한 사각 카펫을 제거해 다이아몬드 바닥 패턴을 살렸습니다. `2F` 반원 홀은 윙에 떠 있던 사각 러그를 제거하고 남측 계단~나침반 장미~중앙 동상 좌대까지 하나의 축선으로 연속된 중앙 레드카펫을 깔았습니다.
- **벽면 액자·장식 정리**: 3칸짜리 벽면 몰딩 박스를 제거한 차분한 크림 회벽 위에 방당 대표 회화/지도 1점 + 스폿 조명 1개 + 황동 벽등 2개만 배치했습니다.

### 2. 측면 3/4 가구, 벽 밀착 서가, 3연 차단봉 & B1 기계 설비 (`map.json`)
총 **174개 오브젝트(`1F 65 · 2F 77 · B1 32`, `puzzle_objects = 0`)**가 동선·문 도착점과 겹치지 않게 배치되었습니다.

- **벽 밀착 & 측면(`좌·우`) 3/4 가구 배치**: 모든 북측 책장·서가는 걸레받이 벽면에 밀착시키고, 각 방 좌/우 내벽에 `side-vitrine-left/right`, `side-shelf-left/right`, `side-bench-left/right`, `side-desk-left/right` 측면 가구를 배치해 방 중앙의 의미 없는 정면 가구 집중을 해소했습니다.
- **3연식 연속 차단봉 (`velvet-fence-3bay.png`)**: 주요 전시대 전면에 1칸짜리 고립 차단봉 대신 4기둥 3연식 벨벳 로프 펜스를 배치했습니다.
- **B1 보일러·급수·고압 전기 설비 구현**: 기존 색만 바꾼 책장류를 제거하고, `safety` 방재실에 **가압 온수 보일러 탱크(`b1-boiler-tank.png`)·벽면 수압 밸브 매니폴드(`b1-side-pipe-manifold-l.png`)·복식 급수 펌프(`b1-pump-manifold.png`)·관제 콘솔(`b1-control-console.png`)**, `power` 전기실에 **3연식 주 고압 배전반(`b1-hv-switchgear.png`)·디젤 발전기(`b1-diesel-generator.png`)·측면 UPS 배터리 랙(`b1-ups-battery-side.png`)·케이블 드럼(`b1-cable-spools.png`)**, `rescue` 수장고에 **항온·제습 공조 유닛(`b1-dehumidifier.png`)·스테인리스 검수대**를 배치했습니다.
