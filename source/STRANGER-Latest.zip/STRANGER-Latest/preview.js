'use strict';

const museum = window.STRANGER_MAP;
const map = document.querySelector('#map');
const ctx = map.getContext('2d');
const floorButtons = [...document.querySelectorAll('[data-floor]')];
const objectList = document.querySelector('#object-list');
const detail = document.querySelector('#detail');
const status = document.querySelector('#status');
const markers = document.querySelector('#markers');
const coordOverlay = document.querySelector('#coord-overlay');
const collision = document.querySelector('#collision');
const scaleCheck = document.querySelector('#scale-check');
const hideDecor = document.querySelector('#without-decor');
const images = new Map();
const player = museum.player;
const held = new Set();
const directions = {
  ArrowLeft: [-1, 0], a: [-1, 0], ArrowRight: [1, 0], d: [1, 0],
  ArrowUp: [0, -1], w: [0, -1], ArrowDown: [0, 1], s: [0, 1],
};
const roomTitle = document.querySelector('#floor-title');
const viewport = {width: 384, height: 256};
const floorNames = {'1F': '1층', '2F': '2층', B1: '지하 B1'};
map.width = viewport.width;
map.height = viewport.height;
let camera = [0, 0];
let floorKey = '1F';
let floor;
let sceneId;
let transitioning = false;
let position;
let selected;
let last = 0;

const puzzleDemo = window.StrangerPuzzleDemo
  ? new window.StrangerPuzzleDemo({
      onJumpToObject(obj) {
        if (!obj) return;
        const targetFloor = obj.floor || findObjectFloor(obj.id) || floorKey;
        const targetRoom = obj.room || museum.floors[targetFloor].defaultScene;
        const dest = obj.interact || [obj.x + Math.round(obj.width / 2), obj.y + obj.height + 8];
        if (targetFloor !== floorKey || targetRoom !== sceneId) {
          setFloor(targetFloor, dest, targetRoom);
        } else {
          position = [...dest];
        }
        const liveObj = floor.objects.find(o => o.id === obj.id) || obj;
        showObject(liveObj);
        status.textContent = `${liveObj.name} · 위치 (${dest[0]}, ${dest[1]}) 이동 완료`;
      },
    })
  : null;

function findObjectFloor(oid) {
  for (const [fid, fl] of Object.entries(museum.floors)) {
    if (fl.objects.some(o => o.id === oid)) return fid;
  }
  return null;
}

function bitmap(path) {
  if (!images.has(path)) {
    const img = new Image();
    img.src = path;
    images.set(path, img);
  }
  return images.get(path);
}

function inside(x, y, [left, top, width, height]) {
  return x >= left && y >= top && x < left + width && y < top + height;
}

function canMove(x, y) {
  const [width, height] = player.footprint;
  const left = Math.floor(x - width / 2);
  const right = Math.ceil(x + width / 2);
  const top = Math.floor(y - height / 2);
  const bottom = Math.ceil(y + height / 2);
  for (let row = top; row <= bottom; row++) {
    const spans = floor.walkableRows[row] ?? [];
    if (!spans.some(([start, end]) => left >= start && right < end)) return false;
  }
  return !floor.objects.some(({collision}) => {
    if (!collision) return false;
    const [u, v, w, h] = collision;
    return left < u + w && right >= u && top < v + h && bottom >= v;
  });
}

function getCamera(view) {
  const party = comparing() ? floor.scaleCheck : null;
  const [x, y] = party
    ? [(party[0][0] + party.at(-1)[0]) / 2, party[0][1]]
    : position;
  function axis(point, start, span, size) {
    if (span <= size) return Math.round(start + (span - size) / 2);
    return Math.round(Math.max(start, Math.min(start + span - size, point - size / 2)));
  }
  return [
    axis(x, view[0], view[2], viewport.width),
    axis(y - 18, view[1], view[3], viewport.height),
  ];
}

function setFloor(key, arrival, nextScene) {
  floorKey = key;
  floor = museum.floors[key];
  sceneId = nextScene || floor.defaultScene;
  const scene = floor.scenes[sceneId];
  position = [...(arrival || floor.spawn)];
  camera = getCamera(scene.view);
  roomTitle.textContent = floorNames[key] + ' · ' + scene.label;
  floorButtons.forEach(btn => btn.setAttribute('aria-pressed', btn.dataset.floor === key));
  objectList.replaceChildren(new Option('현재 방 퍼즐·안내 오브젝트 선택...', ''));
  for (const obj of floor.objects.filter(item => item.interact && (!sceneId || item.room === sceneId))) {
    const num = obj.puzzles.map(n => 'P' + String(n).padStart(2, '0')).join(' · ');
    objectList.add(new Option(num ? num + ' / ' + obj.name : obj.name, obj.id));
  }
  floor.objects.forEach(obj => bitmap(obj.sprite));
  bitmap(floor.background);
  bitmap(floor.walkability);
  player.characters.forEach(character => bitmap(character.sprite));
  showObject(undefined);
  status.textContent = '';
}

function showObject(obj) {
  selected = obj;
  objectList.value = obj?.interact ? obj.id : '';
  const room = floor.rooms.find(item => item.id === obj?.room);
  if (!obj) {
    detail.innerHTML = `<strong>오브젝트 · 좌표 정보</strong>
      <p>지도 위 퍼즐 아이콘이나 상단 <strong>P01~P16</strong> 버튼을 클릭하면 해당 위치 좌표와 어몽어스 태스크가 열립니다.</p>
      <div class="coord-box">현재 위치: <strong>(${Math.round(position[0])}, ${Math.round(position[1])})</strong> · ${floorKey} (${sceneId})</div>`;
    return;
  }

  const pid = obj.puzzles && obj.puzzles[0];
  const puzzleObj = pid && window.STRANGER_PUZZLES ? window.STRANGER_PUZZLES.find(x => x.id === pid) : null;
  const siblings = pid && window.STRANGER_GET_PUZZLE_OBJECTS ? window.STRANGER_GET_PUZZLE_OBJECTS(pid) : [];
  const colStr = obj.collision ? `[${obj.collision.join(', ')}]` : '없음 (통과/벽면)';
  const intStr = obj.interact ? `(${obj.interact[0]}, ${obj.interact[1]})` : '미설정';

  detail.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;flex-wrap:wrap">
      <strong>${obj.name}</strong>
      ${pid ? `<span style="font:800 11px ui-monospace,monospace;padding:2px 6px;border-radius:4px;background:#102D27;border:1px solid #52EFBF;color:#52EFBF">P${String(pid).padStart(2, '0')}</span>` : ''}
    </div>
    <p>${obj.description || '박물관 전시 오브젝트입니다.'}</p>
    <div class="coord-box">
      <div><strong>ID:</strong> ${obj.id} · <strong>방:</strong> ${floorKey}/${room?.id || obj.room}</div>
      <div><strong>오브젝트:</strong> x=${obj.x}, y=${obj.y}, ${obj.width}×${obj.height}px</div>
      <div><strong>상호작용:</strong> ${intStr} · <strong>충돌:</strong> ${colStr}</div>
      ${obj.role ? `<div><strong>담당 역할:</strong> <span style="color:#FFD86B">${obj.role}</span></div>` : ''}
    </div>
    ${pid ? `<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">
      <button id="open-selected-puzzle" style="flex:1;background:#1B6E52;border-color:#52EFBF;color:#fff;font-weight:800">▶ P${String(pid).padStart(2, '0')} 어몽어스 태스크 열기</button>
    </div>` : ''}
    ${siblings.length ? `
      <div style="margin-top:10px;font:700 12px sans-serif;color:#9BB0BE">${puzzleObj ? puzzleObj.code : ''} 연관 맵 오브젝트 (${siblings.length}개):</div>
      <div class="obj-mini-list">
        ${siblings.map(so => `
          <button class="obj-mini-btn" data-sib="${so.id}">
            <span><strong style="color:#89EFD0">${so.id}</strong><br><small style="color:#AAB8C2">${so.role || so.name}</small></span>
            <code style="color:#FFD86B;font-size:11px">(${so.x},${so.y})</code>
          </button>
        `).join('')}
      </div>
    ` : ''}
  `;

  const openBtn = detail.querySelector('#open-selected-puzzle');
  if (openBtn && puzzleDemo) {
    openBtn.onclick = () => puzzleDemo.selectAndOpenPuzzle(pid, false);
  }
  detail.querySelectorAll('[data-sib]').forEach(btn => {
    btn.onclick = () => {
      const target = siblings.find(s => s.id === btn.dataset.sib);
      if (!target) return;
      const dest = target.interact || [target.x + Math.round(target.width / 2), target.y + target.height + 8];
      if (target.floor !== floorKey || target.room !== sceneId) {
        setFloor(target.floor, dest, target.room);
      } else {
        position = [...dest];
      }
      const nextObj = floor.objects.find(o => o.id === target.id);
      if (nextObj) showObject(nextObj);
    };
  });
}

function portalNearby() {
  const [x, y] = position;
  return floor.portals.find(p => p.targetFloor && (!p.sourceScene || p.sourceScene === sceneId) && inside(x, y, p.rect));
}

function closestObject() {
  let distance = player.inspectRadius;
  let found;
  for (const obj of floor.objects) {
    if (!obj.interact || sceneId && obj.room !== sceneId) continue;
    const gap = Math.hypot(position[0] - obj.interact[0], position[1] - obj.interact[1]);
    if (gap < distance) {
      distance = gap;
      found = obj;
    }
  }
  return found;
}

async function useNearby() {
  if (transitioning || comparing()) return;
  const portal = portalNearby();
  if (portal) {
    await changeRoom(portal);
    return;
  }
  const obj = closestObject();
  if (obj) {
    showObject(obj);
    if (puzzleDemo && obj.puzzles && obj.puzzles.length) {
      // If standing on a P16 atrium medallion, credit that pad too!
      if (obj.id.startsWith('gather-')) {
        const idx = Number(obj.id.split('-')[1]) - 1;
        if (!Number.isNaN(idx) && idx >= 0 && idx < 4) {
          puzzleDemo.states[16].pads[idx] = true;
        }
      }
      puzzleDemo.selectAndOpenPuzzle(obj.puzzles[0], false);
    }
  }
  status.textContent = obj ? `조사: ${obj.name}` : '문, 계단 또는 퍼즐 오브젝트에 조금 더 다가가세요.';
}

async function changeRoom(portal) {
  transitioning = true;
  held.clear();
  const skipFade = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  try {
    const out = skipFade ? null : map.animate([{opacity: 1}, {opacity: 0}], {duration: 135, fill: 'forwards'});
    if (out) await out.finished;
    setFloor(portal.targetFloor, portal.arrival, portal.targetScene);
    render();
    if (out) {
      out.cancel();
      await map.animate([{opacity: 0}, {opacity: 1}], {duration: 165}).finished;
    }
    status.textContent = floor.scenes[sceneId].label + ' 도착';
  } finally {
    held.clear();
    transitioning = false;
  }
}

function drawImage(path, x, y, width, height) {
  const img = bitmap(path);
  if (!img.complete || !img.naturalWidth) return;
  if (width && height) {
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'low';
    ctx.drawImage(img, x, y, width, height);
    ctx.imageSmoothingEnabled = false;
  } else {
    ctx.drawImage(img, x, y);
  }
}

function comparing() {
  return scaleCheck.checked && (!floor.scaleCheckScene || floor.scaleCheckScene === sceneId);
}

function drawPlayer([px, py], character) {
  const x = Math.round(px);
  const y = Math.round(py);
  const img = bitmap(character.sprite);
  if (!img.complete || !img.naturalWidth) return;
  const [sx, sy, w, h] = character.frame;
  ctx.drawImage(img, sx, sy, w, h, x - Math.floor(player.width / 2), y - player.height, player.width, player.height);
}

function render() {
  ctx.imageSmoothingEnabled = false;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, map.width, map.height);
  const view = floor.scenes[sceneId].view;
  camera = getCamera(view);
  ctx.setTransform(1, 0, 0, 1, -camera[0], -camera[1]);
  ctx.save();
  ctx.beginPath();
  ctx.rect(...view);
  ctx.clip();
  drawImage(floor.background, 0, 0);
  const visible = floor.objects
    .filter(obj => !hideDecor.checked || obj.interact || !obj.wall && obj.id.endsWith('-table'))
    .sort((a, b) => a.order - b.order);

  const activeCharIdx = puzzleDemo ? ({ doyun: 0, maria: 1, lin: 2, aisha: 3 }[puzzleDemo.activeRole] ?? 0) : 0;
  const party = comparing()
    ? floor.scaleCheck.map((p, index) => [p, player.characters[index]])
    : [[position, player.characters[activeCharIdx]]];

  let index = 0;
  for (const obj of visible) {
    while (index < party.length && party[index][0][1] < obj.order - 4) drawPlayer(...party[index++]);
    drawImage(obj.sprite, obj.x, obj.y, obj.width, obj.height);
  }
  while (index < party.length) drawPlayer(...party[index++]);

  if (collision.checked) {
    ctx.save();
    ctx.globalAlpha = 0.25;
    drawImage(floor.walkability, 0, 0);
    ctx.restore();
    ctx.fillStyle = '#eb7b70';
    for (const obj of floor.objects.filter(item => item.collision)) ctx.fillRect(...obj.collision);
  }

  const nearbyObj = closestObject();
  if (coordOverlay?.checked) {
    ctx.save();
    for (const obj of visible.filter(item => item.interact && item.puzzles.length && (!sceneId || item.room === sceneId))) {
      const pid = obj.puzzles[0];
      const isSolved = puzzleDemo && puzzleDemo.solved.has(pid);
      const isActive = puzzleDemo && puzzleDemo.activePid === pid;
      const isNear = nearbyObj && nearbyObj.id === obj.id;
      ctx.strokeStyle = isSolved ? '#3BE291' : (isNear || isActive ? '#FFD86B' : 'rgba(82,239,191,0.55)');
      ctx.lineWidth = isNear || isActive ? 1.5 : 1;
      ctx.setLineDash([3, 2]);
      ctx.strokeRect(obj.x - 1, obj.y - 1, obj.width + 2, obj.height + 2);
      ctx.setLineDash([]);
      if (obj.interact && (isActive || isNear || selected?.id === obj.id)) {
        ctx.beginPath();
        ctx.arc(obj.interact[0], obj.interact[1], 4, 0, Math.PI * 2);
        ctx.fillStyle = '#FFD86B';
        ctx.fill();
      }
    }
    ctx.restore();
  }

  if (markers.checked) {
    // Draw subtle floor portal location indicators (for unified walls without forced door sprites)
    ctx.save();
    ctx.font = 'bold 6px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const pt of floor.portals) {
      if (pt.sourceScene && pt.sourceScene !== sceneId) continue;
      const [px, py, pw, ph] = pt.rect;
      const isNearPortal = inside(position[0], position[1], pt.rect);
      ctx.fillStyle = isNearPortal ? 'rgba(255,216,107,0.34)' : 'rgba(255,216,107,0.12)';
      ctx.fillRect(px, py, pw, ph);
      ctx.strokeStyle = isNearPortal ? '#FFD86B' : 'rgba(255,216,107,0.65)';
      ctx.lineWidth = isNearPortal ? 1.5 : 1;
      ctx.setLineDash([2, 2]);
      ctx.strokeRect(px + 0.5, py + 0.5, pw - 1, ph - 1);
      ctx.setLineDash([]);
      if (isNearPortal) {
        const cx = px + Math.floor(pw / 2);
        const cy = py - 5;
        ctx.fillStyle = '#3B2809';
        ctx.fillRect(cx - 20, cy - 5, 40, 10);
        ctx.strokeStyle = '#FFD86B';
        ctx.strokeRect(cx - 20, cy - 5, 40, 10);
        ctx.fillStyle = '#FFE89E';
        ctx.fillText('[E] 이동', cx, cy + 0.5);
      }
    }
    ctx.restore();

    ctx.font = 'bold 7px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const obj of visible.filter(item => item.interact && item.puzzles.length && (!sceneId || item.room === sceneId))) {
      const pid = obj.puzzles[0];
      const isSolved = puzzleDemo && puzzleDemo.solved.has(pid);
      const isNear = nearbyObj && nearbyObj.id === obj.id;
      const x = obj.x + Math.floor(obj.width / 2);
      const y = obj.y - 4;
      const label = isNear ? `[E] P${String(pid).padStart(2, '0')}` : `P${String(pid).padStart(2, '0')}`;
      const bw = isNear ? 34 : 18;
      ctx.fillStyle = isSolved ? '#0F3824' : (isNear ? '#4A330B' : '#122026');
      ctx.fillRect(x - bw / 2, y - 5, bw, 10);
      ctx.strokeStyle = isSolved ? '#52EFBF' : (isNear ? '#FFD86B' : '#52EFBF');
      ctx.lineWidth = 0.8;
      ctx.strokeRect(x - bw / 2, y - 5, bw, 10);
      ctx.fillStyle = isNear ? '#FFE799' : '#92F2D1';
      ctx.fillText(label, x, y + 0.5);
    }
  }

  if (selected) {
    ctx.strokeStyle = '#9ffed0';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(selected.x + 0.5, selected.y + 0.5, selected.width, selected.height);
  }
  ctx.restore();
}

function move(keys, amount) {
  if (transitioning || comparing() || puzzleDemo?.modalOpen || puzzleDemo?.cOpen) return;
  let dx = 0;
  let dy = 0;
  for (const key of keys) {
    const dir = directions[key];
    if (dir) {
      dx += dir[0];
      dy += dir[1];
    }
  }
  const stride = Math.hypot(dx, dy);
  if (!stride) return;
  const x = position[0] + dx / stride * amount;
  const y = position[1] + dy / stride * amount;
  if (canMove(x, position[1])) position[0] = x;
  if (canMove(position[0], y)) position[1] = y;
  const portal = portalNearby();
  const nearObj = closestObject();
  if (portal) status.textContent = 'E · ' + portal.name;
  else if (nearObj) status.textContent = `E · ${nearObj.name} (${nearObj.x}, ${nearObj.y})`;
  else if (status.textContent.startsWith('E ·')) status.textContent = '';
}

function frame(time) {
  if (held.size) move(held, Math.min(time - last, 25) * 0.080);
  last = time;
  render();
  window.requestAnimationFrame(frame);
}

window.addEventListener('keydown', event => {
  if (event.target.closest('button,select,input,textarea')) return;
  const key = event.key.length === 1 ? event.key.toLowerCase() : event.key;
  if (Object.hasOwn(directions, key) || key === 'e') event.preventDefault();
  if (!transitioning && Object.hasOwn(directions, key)) held.add(key);
  if (key === 'e' && !event.repeat) {
    if (puzzleDemo?.modalOpen) { puzzleDemo.closeModal(); return; }
    useNearby();
  }
});
window.addEventListener('keyup', event => held.delete(event.key.length === 1 ? event.key.toLowerCase() : event.key));
window.addEventListener('blur', () => held.clear());
for (const button of document.querySelectorAll('[data-key]')) {
  button.addEventListener('pointerdown', event => {
    button.setPointerCapture(event.pointerId);
    held.add(button.dataset.key);
  });
  for (const event of ['pointerup', 'pointercancel', 'lostpointercapture']) {
    button.addEventListener(event, () => held.delete(button.dataset.key));
  }
  button.addEventListener('click', event => move([button.dataset.key], event.detail ? 2 : 8));
}
map.addEventListener('click', event => {
  if (transitioning) return;
  const bounds = map.getBoundingClientRect();
  const x = camera[0] + (event.clientX - bounds.left) * map.width / bounds.width;
  const y = camera[1] + (event.clientY - bounds.top) * map.height / bounds.height;
  if (!inside(x, y, floor.scenes[sceneId].view)) return;
  const obj = [...floor.objects].sort((a, b) => b.order - a.order)
    .find(item => (!hideDecor.checked || item.interact || !item.wall && item.id.endsWith('-table')) && inside(x, y, [item.x, item.y, item.width, item.height]));
  showObject(obj);
  if (obj && puzzleDemo && obj.puzzles && obj.puzzles.length) {
    puzzleDemo.selectAndOpenPuzzle(obj.puzzles[0], false);
  }
});
floorButtons.forEach(btn => btn.addEventListener('click', () => {
  if (transitioning) return;
  setFloor(btn.dataset.floor);
  map.focus();
}));
document.querySelector('#interact').addEventListener('click', useNearby);
objectList.addEventListener('change', () => {
  const obj = floor.objects.find(o => o.id === objectList.value);
  if (obj && obj.interact) position = [...obj.interact];
  showObject(obj);
});
scaleCheck.addEventListener('change', () => {
  held.clear();
  status.textContent = comparing()
    ? '원본 크기 30×50px로 네 명을 비교할 수 있어요. 다시 이동하려면 비교 표시를 끄세요.'
    : '';
});
setFloor('1F');
window.requestAnimationFrame(frame);
