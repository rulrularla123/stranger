(function () {
  'use strict';

  const ROLES = {
    doyun: { id: 'doyun', name: '도윤', title: '엔지니어 · 조작자', color: '#FFB86B', badge: '⚙', desc: '기계·밸브·로프·배전반 하이라이트 및 정밀 조작' },
    maria: { id: 'maria', name: '마리아', title: '고문서학자 · 통역', color: '#E6C886', badge: '📜', desc: '방명록·연표·바이바이인·스페인어 사료 번역' },
    lin:   { id: 'lin',   name: '린',   title: '공간측량사 · 네비게이터', color: '#52EFBF', badge: '🧭', desc: '방위·배관 계통도·선로/광학 축선·좌표 측량' },
    aisha: { id: 'aisha', name: '아이샤', title: '유물감식가 · 관측자', color: '#7CD8FF', badge: '🔍', desc: '회화 루페·마이크로 센서·화학·보존 정밀 관측' },
  };

  const C_CATEGORIES = [
    {
      id: 'num',
      label: '① 수치·순서',
      color: '#F4F7FA',
      tokens: [
        { id: 'NUM_1', glyph: '①', label: '1번', sub: '첫번째/1단위', color: '#F4F7FA' },
        { id: 'NUM_2', glyph: '②', label: '2번', sub: '두번째/2단위', color: '#F4F7FA' },
        { id: 'NUM_3', glyph: '③', label: '3번', sub: '세번째/3단위', color: '#F4F7FA' },
        { id: 'NUM_4', glyph: '④', label: '4번', sub: '네번째/4단위', color: '#F4F7FA' },
        { id: 'NUM_0', glyph: '◎0', label: '기준(0)', sub: '영점/초기화', color: '#9AA7B4' },
      ],
    },
    {
      id: 'dir',
      label: '② 방위·동작',
      color: '#52EFBF',
      tokens: [
        { id: 'DIR_N', glyph: '↑', label: '북 ↑', sub: '위 / 북쪽', color: '#52EFBF' },
        { id: 'DIR_E', glyph: '→', label: '동 →', sub: '오른쪽 / 동', color: '#52EFBF' },
        { id: 'DIR_S', glyph: '↓', label: '남 ↓', sub: '아래 / 남쪽', color: '#52EFBF' },
        { id: 'DIR_W', glyph: '←', label: '서 ←', sub: '왼쪽 / 서쪽', color: '#52EFBF' },
        { id: 'ACT_ROT', glyph: '↻', label: '회전 ↻', sub: '링·원판 돌리기', color: '#FFB86B' },
      ],
    },
    {
      id: 'sym',
      label: '③ 문양·속성',
      color: '#E6C886',
      tokens: [
        { id: 'SYM_SUN', glyph: '☀', label: '태양 ☀', sub: '황금/지붕/호박', color: '#E6C886' },
        { id: 'SYM_WAVE', glyph: '🌊', label: '파도 🌊', sub: '청록/해협/습도', color: '#7CD8FF' },
        { id: 'SYM_MTN', glyph: '⛰', label: '산맥 ⛰', sub: '황토/기둥/지형', color: '#D49B6A' },
        { id: 'SYM_STAR', glyph: '★', label: '별자리 ★', sub: '감청/바이바이인', color: '#91A8FF' },
        { id: 'SYM_VOLT', glyph: '⚡', label: '열기 ⚡', sub: '적색/과압/전류', color: '#FF6E6E' },
        { id: 'SYM_SAFE', glyph: '🛡', label: '안정 🛡', sub: '녹색/개방/완전', color: '#52EFBF' },
      ],
    },
    {
      id: 'coop',
      label: '④ 협동 콜사인',
      color: '#C792EA',
      tokens: [
        { id: 'COOP_OK', glyph: '✔', label: '준비 완료', sub: 'OK / 작동 가능', color: '#52EFBF' },
        { id: 'COOP_WAIT', glyph: '✋', label: '잠깐 대기', sub: 'HOLD / 정지', color: '#FFB86B' },
        { id: 'COOP_SWAP', glyph: '⇄', label: '반전/교체', sub: '대각선/모선 우회', color: '#C792EA' },
        { id: 'COOP_HERE', glyph: '📍', label: '집결 호출', sub: 'HERE / 반원 홀', color: '#52EFBF' },
      ],
    },
  ];

  const TOKENS_BY_ID = Object.fromEntries(C_CATEGORIES.flatMap(c => c.tokens).map(t => [t.id, t]));

  const PUZZLES = [
    {
      id: 1, code: 'P01', act: 1, floor: '1F', room: 'hall', roomLabel: '1F · 중앙 복도',
      title: '로비 나침반과 4대 전시관 방위 개방',
      arch: '동심원 4방위 베젤 링 회전 정렬',
      mainRole: 'lin', helperRoles: ['maria'], focusObj: 'hall-compass-dial',
      answerTokens: [['DIR_N', 'SYM_SUN'], ['DIR_S', 'SYM_WAVE']],
      clueTitle: '마리아 · 안내 데스크 개관 방명록 번역',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>📜 개관 방명록 원본 대조 (hall-reception):</strong></p>
        <div class="au-clue-grid">
          <div class="au-clue-chip"><span>↑ 북 (0°)</span><strong style="color:#E6C886">☀ 태양 · 생활사</strong></div>
          <div class="au-clue-chip"><span>→ 동 (90°)</span><strong style="color:#91A8FF">★ 별 · 역사 연표</strong></div>
          <div class="au-clue-chip"><span>↓ 남 (180°)</span><strong style="color:#7CD8FF">🌊 파도 · 근현대 도시</strong></div>
          <div class="au-clue-chip"><span>← 서 (270°)</span><strong style="color:#D49B6A">⛰ 산맥 · 공예 기술</strong></div>
        </div>
        <p class="au-clue-note">외륜 방위 <strong>북(N)</strong>이 12시(0°)를 가리키고, 내륜 <strong>태양(☀)</strong>도 같은 12시에 겹치게 맞춘 뒤 잠금 레버를 당기세요.</p>
      </div>`,
    },
    {
      id: 2, code: 'P02', act: 1, floor: '1F', room: 'life', roomLabel: '1F · 생활사 전시실',
      title: '바하이 쿠보(Bahay Kubo) 3층위 생활 유물 배치',
      arch: '전통 가옥 3단 단면 층위 드래그·슬롯 장착',
      mainRole: 'aisha', helperRoles: ['maria'], focusObj: 'life-table-center',
      answerTokens: [['NUM_1', 'SYM_SUN'], ['NUM_3', 'SYM_MTN']],
      clueTitle: '마리아 · 타갈로그 생활 주석 서가',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>📚 서측 벽면 서가 어휘 해독 (life-side-shelf-w):</strong></p>
        <ul class="au-clue-list">
          <li><strong>① 지붕 다락 (Bubong · ☀)</strong> → 직사광선 아래 말려 저장하는 <code>건조 곡식 단지</code></li>
          <li><strong>② 대나무 마루 (Sala · 🌊)</strong> → 바람 통하는 생활 공간에 두는 <code>대나무 직조 바구니</code></li>
          <li><strong>③ 기둥 하부 (Silong · ⛰)</strong> → 흙바닥 고상 기둥 아래 무거운 작업용 <code>돌절구</code></li>
        </ul>
      </div>`,
    },
    {
      id: 3, code: 'P03', act: 1, floor: '1F', room: 'life', roomLabel: '1F · 생활사 전시실',
      title: '마눙굴 항아리 뚜껑 영혼의 배 복원',
      arch: '360° 원통 턴테이블 회전 + 파편 음각 각도 조립',
      mainRole: 'aisha', helperRoles: ['doyun'], focusObj: 'life-case-nw',
      answerTokens: [['ACT_ROT', 'SYM_WAVE']],
      clueTitle: '도윤 · 진열장 받침 톱니 결합 점검',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>⚙ 수직 진열장 명판 기어 실측 (life-vitrine-ne):</strong></p>
        <p>몸체의 나선 파도 음각 홈은 <strong>180° 방향</strong>에 파여 있습니다. 턴테이블을 <strong>180°</strong>까지 돌리고, 뚜껑 위 <strong>영혼의 배 기울기를 0°(수평)</strong>로 맞춘 뒤 클램프를 체결하세요.</p>
      </div>`,
    },
    {
      id: 4, code: 'P04', act: 1, floor: '1F', room: 'time', roomLabel: '1F · 역사 연표 전시실',
      title: '군도 항해 지도와 3대 독립 연표 크로스라인',
      arch: '2D 고지도 해협 핀 × 타임라인 SVG 크로스라인 결선',
      mainRole: 'maria', helperRoles: ['lin'], focusObj: 'time-table-center',
      answerTokens: [['NUM_2', 'DIR_W'], ['NUM_3', 'DIR_N']],
      clueTitle: '린 · 필리핀 군도 고지도 해협 측량',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🧭 북측 고지도 좌표 측량 결과 (time-wall-art):</strong></p>
        <ul class="au-clue-list">
          <li><strong>1521 막탄 항해</strong> ↔ <code>비사야 해협 (Visayas · 동남 해역)</code></li>
          <li><strong>1898 말롤로스 헌법</strong> ↔ <code>말롤로스 성당 (서쪽 루손 만)</code></li>
          <li><strong>1946 공화국 독립</strong> ↔ <code>마닐라 북부 광장 (북↑ 내륙)</code></li>
        </ul>
      </div>`,
    },
    {
      id: 5, code: 'P05', act: 1, floor: '1F', room: 'craft', roomLabel: '1F · 공예·기술 전시실',
      title: '이푸가오 전통 베틀 3색 씨실·날실 교차',
      arch: '3단 종광 페달 개구 토글 + 3색 북 왕복 시퀀스',
      mainRole: 'doyun', helperRoles: ['aisha'], focusObj: 'craft-table-center',
      answerTokens: [['SYM_SUN', 'SYM_VOLT'], ['SYM_WAVE']],
      clueTitle: '아이샤 · 직조 벽면 직물 루페 확대',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🔍 확대 루페 실 배색 관측 (craft-wall-art):</strong></p>
        <p>위에서 아래로 3줄 순서: <strong>1줄 [☀ 황금 실] → 2줄 [⚡ 진홍 실] → 3줄 [🌊 청록 실]</strong>.</p>
        <p class="au-clue-note">각 줄에 해당하는 <strong>페달(1→2→3)</strong>을 먼저 밟아 실틈을 연 상태에서 맞는 색상의 북(Shuttle)을 통과시키세요.</p>
      </div>`,
    },
    {
      id: 6, code: 'P06', act: 1, floor: '1F', room: 'city', roomLabel: '1F · 근현대 도시 전시실',
      title: '1910 마닐라 전차(Tranvia) 분기선과 파시그강 도개교',
      arch: '디오라마 3분기 선로 레버 + 광학 뷰파인더 조준',
      mainRole: 'lin', helperRoles: ['maria'], focusObj: 'city-table-center',
      answerTokens: [['NUM_2', 'DIR_E']],
      clueTitle: '마리아 · 1910 전차 노선 푯말 및 시간표 번역',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>📜 거리화 스페인어 표지 &amp; 시간표 (city-wall-art):</strong></p>
        <p>"긴급 보수 우회 경로: 중앙선(S1=<strong>B분기</strong>)에서 <strong>2번 비논도 차이나타운 노선(S2=B분기)</strong>을 타고 마지막 도개교 스위치(S3=<strong>A 본선</strong>)로 합류한 뒤 <strong>동쪽(→ 90°) 도개교</strong>를 주시하며 출발하라."</p>
      </div>`,
    },
    {
      id: 7, code: 'P07', act: 2, floor: 'B1', room: 'maintenance', roomLabel: 'B1 · ㄱ자 관리 통로',
      title: '지하 주 급수관 3구역 바이패스 수압 평형',
      arch: '연동 유량 핸드휠 밸브 3개 아날로그 PSI 평형',
      mainRole: 'doyun', helperRoles: ['lin'], focusObj: 'maint-pipe-header-1',
      answerTokens: [['NUM_1', 'SYM_VOLT'], ['NUM_3', 'SYM_SAFE']],
      clueTitle: '린 · 배관 계통도 3구역 허용 압력 측정',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🧭 계측 제어함 배관 설계표 (maint-conduit-1):</strong></p>
        <p>목표: 3개 구역 게이지 모두 녹색 안전 대역 <strong>60 PSI (55~65 PSI)</strong> 일치!</p>
        <p class="au-clue-note">추천 목표 개방률: <strong>1번 밸브 25%</strong> · <strong>2번 밸브 50%</strong> · <strong>3번 밸브 100% 완전 개방</strong></p>
      </div>`,
    },
    {
      id: 8, code: 'P08', act: 2, floor: 'B1', room: 'safety', roomLabel: 'B1 · 방재·보일러실',
      title: '가압 보일러 증기 감압 & 복식 순환 펌프 동기화',
      arch: '보일러 실시간 감압 밸브 + 듀얼 RPM 위상 동기화',
      mainRole: 'doyun', helperRoles: ['aisha'], focusObj: 'safety-pump',
      answerTokens: [['SYM_VOLT', 'DIR_S'], ['NUM_2', 'SYM_SAFE']],
      clueTitle: '아이샤 · 방재 관제 콘솔 열화상 & 주파수 뷰',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🔍 방재 콘솔 듀얼 모니터 관측 (safety-console):</strong></p>
        <ul class="au-clue-list">
          <li>1단계: 보일러 압력을 위험 적색(145 PSI)에서 <strong>70~90 PSI</strong>로 낮추세요.</li>
          <li>2단계: 1호기·2호기 펌프를 모두 <strong>1200 RPM (±30 오차 내)</strong>으로 맞춘 뒤 동기 잠금을 누르세요.</li>
        </ul>
      </div>`,
    },
    {
      id: 9, code: 'P09', act: 2, floor: 'B1', room: 'power', roomLabel: 'B1 · 고압 전기실',
      title: '3연식 고압 배전반 모선 라우팅 & 비상 발전기 기동',
      arch: '예열·크랭크 기동 + 3베이 모선 인터록 매트릭스',
      mainRole: 'doyun', helperRoles: ['lin', 'aisha'], focusObj: 'power-switchgear',
      answerTokens: [['NUM_3', 'COOP_SWAP'], ['COOP_OK']],
      clueTitle: '린 & 아이샤 · UPS 단락표 & 발전기 주파수 계측',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🧭+🔍 합동 전력 점검 보고 (power-ups-e1 / power-conduit):</strong></p>
        <ul class="au-clue-list">
          <li><strong>린(UPS 랙):</strong> 1번·2번 모선은 침수 단락 → <strong>OFF 차단</strong>! 오직 <strong>3번 우회 모선만 ON</strong> 투입.</li>
          <li><strong>아이샤(제어함):</strong> 먼저 <strong>디젤 발전기 예열 → 크랭크 시동(60Hz)</strong>을 완료한 뒤 주 차단기를 올리세요.</li>
        </ul>
      </div>`,
    },
    {
      id: 10, code: 'P10', act: 2, floor: 'B1', room: 'rescue', roomLabel: 'B1 · 응급 수장고',
      title: '수장고 이슬점 제습 공조 & 2축 천장 호이스트 이송',
      arch: '온습도 이슬점 캘리브레이션 + 침수 회피 2D 크레인',
      mainRole: 'lin', helperRoles: ['aisha', 'doyun'], focusObj: 'rescue-table-c',
      answerTokens: [['SYM_WAVE', 'DIR_N'], ['NUM_1', 'SYM_SAFE']],
      clueTitle: '아이샤 & 도윤 · 수장 권장 기준 & 침수 구역',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🔍+⚙ 수장고 합동 브리핑 (rescue-dehumid-nw / rescue-crate-sw1):</strong></p>
        <p>먼저 공조기 이슬점을 <strong>습도 45% RH / 온도 18°C</strong>로 맞춰 안개를 걷히게 한 뒤, 크레인으로 <strong>(1,3)의 1번 상자</strong>를 인양해 물웅덩이 칸을 피해 <strong>북동쪽 (4,1) 스틸 선반</strong>에 안착시키세요.</p>
      </div>`,
    },
    {
      id: 11, code: 'P11', act: 3, floor: '2F', room: 'archive', roomLabel: '2F · 기록 아카이브',
      title: '카티푸난 비밀 헌장과 바이바이인 이중 암호판',
      arch: '바이바이인 음절 자음·쿠들릿 모음점 이중 디코더 휠',
      mainRole: 'maria', helperRoles: ['aisha', 'doyun'], focusObj: 'archive-table',
      answerTokens: [['SYM_STAR', 'ACT_ROT'], ['NUM_3', 'SYM_SUN']],
      clueTitle: '아이샤 & 도윤 · UV 헌장 스캔 & 목판 기준',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🔍+⚙ 암호 해독 단서 (archive-paint / archive-long-nw):</strong></p>
        <p>카티푸난 독립 표어 <strong>KALAYAAN (자유)</strong>의 앞 3음절: <strong>① KA (ᜃ · 무점) · ② LA (ᜎ · 무점) · ③ YA (ᜌ · 무점)</strong>. 내륜에서 자음을, 외륜에서 Kudlit 모음점을 <strong>무점(a음)</strong>으로 맞추세요.</p>
      </div>`,
    },
    {
      id: 12, code: 'P12', act: 3, floor: '2F', room: 'archive', roomLabel: '2F · 기록 아카이브',
      title: '기증 등록대장 마이크로필름 & 천공 카드 복원',
      arch: 'XY 마이크로필름 초점 스캐너 + 4열 천공 카드 타공',
      mainRole: 'maria', helperRoles: ['lin'], focusObj: 'archive-cabinet-ne',
      answerTokens: [['NUM_2', 'SYM_STAR'], ['NUM_4', 'SYM_WAVE']],
      clueTitle: '린 · 동측 책상 마이크로필름 XY 좌표',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🧭 마이크로필름 판독 (archive-side-desk-e):</strong></p>
        <p>필름 스캐너 초점을 <strong>X=60, Y=40</strong>에 맞추면 선명한 등록 코드가 나타납니다: <strong>2열(★ 별)</strong> &amp; <strong>4열(🌊 파도)</strong> 두 칸만 타공한 뒤 황동 스탬프를 찍으세요.</p>
      </div>`,
    },
    {
      id: 13, code: 'P13', act: 3, floor: '2F', room: 'preserve', roomLabel: '2F · 보존처리실',
      title: '청동 유물 부식층 초음파 세척 & 3색 시약 적정',
      arch: '스포이드 pH 7.0 적정 + 캔버스 초음파 브러시 세척',
      mainRole: 'aisha', helperRoles: ['maria', 'doyun'], focusObj: 'preserve-lab-c',
      answerTokens: [['SYM_WAVE', 'NUM_2'], ['SYM_SUN', 'NUM_1']],
      clueTitle: '마리아 & 도윤 · 스페인어 시약 비율 & 안전 밸브',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>📜+⚙ 화학 공정 노트 (preserve-wall-chart):</strong></p>
        <p>시약 공식: <strong>🌊 청록 염화물 2방울 + ☀ 황금 호박산 1방울 = 완벽 중화 pH 7.0</strong>. 중화 완료 후 아래 <strong>청동 유물 위 부식층을 마우스로 문질러(90% 이상)</strong> 세척하세요!</p>
      </div>`,
    },
    {
      id: 14, code: 'P14', act: 3, floor: '2F', room: 'preserve', roomLabel: '2F · 보존처리실',
      title: '기증 상자 4점 도르래 이완 & 밀랍 봉인 몰드',
      arch: '대각선 장력 평형 슬라이더 + 깨진 밀랍 인장 압착',
      mainRole: 'aisha', helperRoles: ['doyun'], focusObj: 'preserve-bench-r',
      answerTokens: [['NUM_1', 'COOP_SWAP'], ['SYM_SAFE']],
      clueTitle: '도윤 · 기증 상자 도르래 대각선 장력 점검',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>⚙ 로프 하중 균형 규칙 (preserve-crate-sw):</strong></p>
        <p>인접 모서리를 연속으로 풀면 상자가 뒤틀려 안전 걸쇠가 잠깁니다! 반드시 <strong>①(좌상) → 대각선 ③(우하)</strong>을 먼저 0%로 내린 뒤 <strong>②(우상) → ④(좌하)</strong>를 푸세요. 그다음 밀랍 조각 3개를 ` + '`0°`' + ` 정렬 후 압착!</p>
      </div>`,
    },
    {
      id: 15, code: 'P15', act: 3, floor: '2F', room: 'reading', roomLabel: '2F · 자료 열람실',
      title: '고서 지명 색인과 성곽 도면 트레이싱 오버레이',
      arch: '반투명 트레이싱 도면 X·Y 드래그 & 90° 정합 포개기',
      mainRole: 'maria', helperRoles: ['lin'], focusObj: 'reading-table',
      answerTokens: [['DIR_W', 'ACT_ROT']],
      clueTitle: '린 · 사료화 속 성곽 축선 오프셋 측정',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>🧭 사료화 종탑 측량 결과 (reading-wall-art-c):</strong></p>
        <p>반투명 도면을 회전 버튼으로 <strong>0°(정방향)</strong> 맞춘 뒤, <strong>X=0, Y=0 중앙</strong>의 3개 성곽 앵커(Puerta Real · Baluarte · Santiago) 위로 직접 드래그해 포개세요.</p>
      </div>`,
    },
    {
      id: 16, code: 'P16', act: 4, floor: '2F', room: 'special', roomLabel: '2F · 기획전시실 → 반원 홀',
      title: '해양 교역 프리즘 연결 & 반원 홀 4인 대관식 집결',
      arch: '1부: 3프리즘 광선 반사 + 2부: 반원 홀 발판 4/4 집결',
      mainRole: 'lin', helperRoles: ['maria', 'doyun', 'aisha'], focusObj: 'special-table',
      answerTokens: [['DIR_E', 'ACT_ROT'], ['COOP_HERE']],
      clueTitle: '마리아 · 해양 교류 벽화 광학 항로 & 4인 집결 규칙',
      clueHtml: `<div class="au-clue-sheet">
        <p><strong>📜+✨ 최종 피날레 2단계 (special-wall-art → atrium):</strong></p>
        <ul class="au-clue-list">
          <li><strong>1부(기획전시실):</strong> 3개 크리스탈 프리즘 각도를 맞춰 태양 광선이 반원 홀 동상으로 뻗어나가게 하세요 (<strong>M1: ╲ 45°, M2: ╱ 135°, M3: ━ 0°/직진</strong> 또는 각도 클릭 회전).</li>
          <li><strong>2부(반원 홀):</strong> 빛 연결 후 C메뉴 <strong>[집결 호출]</strong>을 발신하고 나침반 주변 4개 발판(<code>gather-1..4</code>)에 4인이 전원 모이면 개관식이 완성됩니다!</li>
        </ul>
      </div>`,
    },
  ];

  // Dynamic map object lookup from window.STRANGER_MAP
  function getPuzzleObjects(pid) {
    const m = window.STRANGER_MAP;
    if (!m) return [];
    const list = [];
    for (const [fid, fl] of Object.entries(m.floors)) {
      for (const o of fl.objects) {
        if (o.puzzles && o.puzzles.includes(pid)) {
          list.push({ floor: fid, ...o });
        }
      }
    }
    // Put interact-main object first
    list.sort((a, b) => {
      const am = (a.role || '').includes('★') ? -1 : 0;
      const bm = (b.role || '').includes('★') ? -1 : 0;
      return am - bm;
    });
    return list;
  }

  function initialStates() {
    return {
      1: { outerDeg: 90, innerDeg: 180, locked: false },
      2: { slots: { roof: null, floor: null, stilt: null }, picked: null },
      3: { turntableDeg: 60, lidTiltDeg: -15, seated: false },
      4: { selectedLeft: null, links: { '1521': null, '1898': null, '1946': null } },
      5: { heddleOpen: [false, false, false], rows: [null, null, null] },
      6: { switches: ['A', 'A', 'B'], dir: 'N', dispatched: false },
      7: { valves: [75, 50, 25] },
      8: { boilerPsi: 145, pump1Rpm: 800, pump2Rpm: 1550, synced: false },
      9: { heat: 0, genRunning: false, bus: [true, true, false], breaker: false },
      10: { rh: 72, temp: 24, crane: [1, 1], cratePos: [1, 3], holding: false },
      11: { activeSlot: 0, slots: [{ syl: 'BA', kudlit: 'up' }, { syl: 'MA', kudlit: 'down' }, { syl: 'PA', kudlit: 'up' }] },
      12: { fx: 15, fy: 85, holes: [false, false, false, false], stamped: false },
      13: { cyan: 0, amber: 0, scrubGrid: new Array(24).fill(false), scrubDone: false },
      14: { rope: [100, 100, 100, 100], waxRot: [90, 180, 270], pressed: false },
      15: { ox: 96, oy: -48, rot: 270 },
      16: { phase: 1, prisms: [0, 45, 90], beamOk: false, hereSent: false, pads: [false, false, false, false] },
    };
  }

  // Styles for Among Us / Goose Goose Duck tactile modal & C-Menu 2.0
  function injectStyles() {
    if (document.getElementById('stranger-au-css')) return;
    const st = document.createElement('style');
    st.id = 'stranger-au-css';
    st.textContent = `
      .au-hud-bar { display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:10px;
        background:#131820; border:3px solid #0B0E13; box-shadow:inset 0 2px 0 #26313E, 0 4px 0 #080A0D;
        border-radius:8px; padding:10px 14px; margin-bottom:12px; }
      .au-progress-wrap { display:flex; align-items:center; gap:10px; min-width:240px; flex:1; }
      .au-progress-track { flex:1; height:18px; background:#0A0D12; border:3px solid #0B0E13; border-radius:4px; overflow:hidden; position:relative; }
      .au-progress-fill { height:100%; background:repeating-linear-gradient(-45deg, #27BA74, #27BA74 10px, #3BE291 10px, #3BE291 20px);
        transition:width .25s ease; }
      .au-progress-label { font:800 12px ui-monospace,monospace; color:#52EFBF; min-width:98px; }
      .au-radio-banner { display:flex; align-items:center; gap:8px; background:#0D1C22; border:2px solid #52EFBF;
        padding:5px 10px; border-radius:6px; font-size:13px; color:#EAF6F2; min-height:34px; }
      .au-tok-pill { display:inline-flex; align-items:center; gap:4px; padding:2px 8px; border-radius:4px;
        font:800 12px/1.3 sans-serif; background:#141E26; border:2px solid currentColor; }
      .au-quick-strip { display:grid; grid-template-columns:repeat(8, minmax(0, 1fr)); gap:6px; margin-bottom:12px; }
      @media(max-width:960px){ .au-quick-strip { grid-template-columns:repeat(4, minmax(0, 1fr)); } }
      .au-pq-btn { text-align:left; padding:6px 8px; border-radius:6px; border:2px solid #0B0E13; background:#19212B;
        box-shadow:0 3px 0 #090C10; cursor:pointer; display:flex; flex-direction:column; gap:2px; transition:transform .08s; }
      .au-pq-btn:hover { transform:translateY(-1px); border-color:#52EFBF; }
      .au-pq-btn.active { background:#13322D; border-color:#52EFBF; box-shadow:0 0 0 2px rgba(82,239,191,.35), 0 3px 0 #090C10; }
      .au-pq-btn.solved { background:#102B1F; border-color:#3BE291; }
      .au-pq-top { display:flex; justify-content:space-between; align-items:center; font:800 11px ui-monospace,monospace; }
      .au-pq-sub { font-size:11px; color:#AAB8C2; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

      .au-backdrop { position:fixed; inset:0; background:rgba(6,9,13,.76); backdrop-filter:blur(2px);
        z-index:900; display:none; align-items:center; justify-content:center; padding:16px; }
      .au-backdrop.open { display:flex; }
      .au-modal { width:min(860px, 100%); max-height:92vh; overflow:auto; background:#232B35;
        border:5px solid #0B0E13; border-radius:14px;
        box-shadow:0 20px 60px rgba(0,0,0,.85), inset 0 3px 0 #455466, inset 0 -4px 0 #141920;
        color:#F0F4F8; position:relative; }
      .au-modal-head { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;
        background:#161C24; border-bottom:4px solid #0B0E13; padding:10px 14px; position:sticky; top:0; z-index:4; }
      .au-rivet { width:10px; height:10px; border-radius:50%; background:#4D5B6B; border:2px solid #0B0E13; box-shadow:inset 1px 1px 0 #7E90A4; display:inline-block; }
      .au-close-x { width:34px; height:34px; border-radius:8px; background:#C9362C; border:3px solid #0B0E13;
        color:#fff; font:900 16px sans-serif; box-shadow:0 3px 0 #69140E; cursor:pointer; }
      .au-close-x:hover { background:#E84A3E; }
      .au-modal-sub { display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:8px;
        background:#1B222C; border-bottom:3px solid #0B0E13; padding:8px 14px; }
      .au-view-tabs { display:flex; gap:6px; flex-wrap:wrap; }
      .au-vtab { padding:5px 10px; border-radius:6px; border:2px solid #0B0E13; background:#2B3543; color:#C6D2DC;
        font:700 12px sans-serif; cursor:pointer; }
      .au-vtab.active { background:#52EFBF; color:#0B1316; border-color:#0B0E13; }
      .au-body { padding:14px 16px 16px; position:relative; }
      .au-board { background:#151B22; border:4px solid #0B0E13; border-radius:10px; padding:14px;
        box-shadow:inset 0 2px 10px rgba(0,0,0,.6); }
      .au-btn { padding:8px 14px; border-radius:7px; border:3px solid #0B0E13; background:#313E4E; color:#F2F6FA;
        font:800 13px sans-serif; box-shadow:0 3px 0 #0B0E13; cursor:pointer; transition:transform .07s; }
      .au-btn:hover { filter:brightness(1.12); }
      .au-btn:active { transform:translateY(2px); box-shadow:0 1px 0 #0B0E13; }
      .au-btn.primary { background:#27BA74; color:#071710; }
      .au-btn.amber { background:#E39B38; color:#191005; }
      .au-btn.danger { background:#B73A32; color:#fff; }
      .au-feedback { margin-top:10px; padding:8px 12px; border-radius:6px; border:2px solid #0B0E13;
        background:#11171D; font:700 13px sans-serif; color:#BFD0DC; min-height:36px; display:flex; align-items:center; justify-content:space-between; gap:8px; }
      .au-feedback.ok { background:#0F3323; border-color:#52EFBF; color:#7FFFD4; }
      .au-feedback.err { background:#351517; border-color:#FF6E6E; color:#FFB3B3; animation:auShake .28s; }
      @keyframes auShake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-6px)} 75%{transform:translateX(6px)} }

      .au-pin-radio { display:flex; align-items:center; gap:8px; flex-wrap:wrap; background:#0F1A20;
        border:2px solid #2A434D; border-radius:6px; padding:6px 10px; margin-bottom:10px; font-size:12px; }
      .au-obj-table { width:100%; border-collapse:collapse; font-size:12px; margin-top:8px; }
      .au-obj-table th, .au-obj-table td { border:1px solid #2B3642; padding:5px 7px; text-align:left; }
      .au-obj-table th { background:#11171E; color:#8DE8CA; font:700 11px ui-monospace,monospace; }
      .au-obj-row { cursor:pointer; }
      .au-obj-row:hover { background:#1F2B36; }

      .au-clue-sheet { background:#251E15; border:3px solid #6B5233; border-radius:8px; padding:12px; color:#F2E4C8; }
      .au-clue-grid { display:grid; grid-template-columns:repeat(2, minmax(0,1fr)); gap:8px; margin:8px 0; }
      .au-clue-chip { background:#17120C; border:2px solid #4E3C25; padding:7px 9px; border-radius:6px; display:flex; justify-content:space-between; }
      .au-clue-list { margin:8px 0 0 18px; padding:0; display:grid; gap:5px; }
      .au-clue-note { margin-top:8px; font-size:12px; color:#D8C39E; }

      .au-stamp-clear { display:flex; align-items:center; justify-content:center; gap:10px; margin-top:10px;
        background:linear-gradient(90deg, #103A27, #1A6242, #103A27); border:3px solid #52EFBF;
        border-radius:8px; padding:10px; font:900 16px ui-monospace,monospace; color:#7FFFD4; letter-spacing:.08em; }

      /* C-Menu 2.0 Wheel Drawer */
      .au-cmenu-panel { position:fixed; right:18px; bottom:18px; z-index:950; width:min(400px, calc(100vw - 24px));
        background:#161D25; border:4px solid #0B0E13; border-radius:14px;
        box-shadow:0 16px 40px rgba(0,0,0,.8), inset 0 2px 0 #394858; display:none; padding:12px; }
      .au-cmenu-panel.open { display:block; }
      .au-c-grid { display:grid; grid-template-columns:repeat(5, minmax(0,1fr)); gap:5px; margin-top:6px; }
      .au-c-tok { padding:5px 3px; border-radius:6px; border:2px solid #0B0E13; background:#202A35; cursor:pointer;
        display:flex; flex-direction:column; align-items:center; gap:2px; font-size:10px; text-align:center; }
      .au-c-tok:hover { border-color:#52EFBF; }
      .au-c-tok.sel { background:#14382F; border-color:#52EFBF; box-shadow:0 0 0 2px rgba(82,239,191,.35); }
      .au-c-fab { position:fixed; right:18px; bottom:18px; z-index:920; padding:10px 16px; border-radius:999px;
        background:#1E2A36; border:4px solid #0B0E13; color:#52EFBF; font:900 13px sans-serif;
        box-shadow:0 6px 0 #080B0F, 0 10px 25px rgba(0,0,0,.6); cursor:pointer; display:flex; align-items:center; gap:6px; }

      /* Specific game widgets */
      .au-slot-box { border:3px dashed #5B6E80; background:#10151B; border-radius:8px; padding:8px 10px;
        display:flex; align-items:center; justify-content:space-between; min-height:46px; cursor:pointer; }
      .au-slot-box.filled { border-style:solid; border-color:#52EFBF; background:#122923; }
      .au-card-chip { padding:7px 10px; border-radius:7px; border:3px solid #0B0E13; background:#2B3644;
        cursor:pointer; font:700 12px sans-serif; display:inline-flex; align-items:center; gap:6px; box-shadow:0 3px 0 #0B0E13; }
      .au-card-chip.picked { border-color:#FFD86B; background:#3E331A; }
      .au-grid-5x4 { display:grid; grid-template-columns:repeat(5, 52px); gap:4px; background:#0C1116; padding:8px; border:3px solid #0B0E13; border-radius:8px; width:max-content; }
      .au-cell { width:52px; height:44px; border:2px solid #26313D; border-radius:5px; background:#1A232D;
        display:flex; flex-direction:column; align-items:center; justify-content:center; font:700 11px monospace; }
      .au-cell.puddle { background:#123850; border-color:#4FB4E8; color:#7CD8FF; }
      .au-cell.rack { background:#113825; border-color:#52EFBF; color:#7FFFD4; }
    `;
    document.head.appendChild(st);
  }

  class StrangerPuzzleDemo {
    constructor(host) {
      this.host = host; // { onJumpToObject(obj), getPosition(), getFloorKey() }
      injectStyles();
      this.states = initialStates();
      this.solved = new Set();
      this.activePid = 1;
      this.activeRole = 'lin';
      this.viewMode = 'main'; // 'main' | 'clue' | 'coords'
      this.feedback = { msg: '', kind: '' };
      this.radioLog = [];
      this.cSel = [];
      this.cOpen = false;
      this.modalOpen = false;
      this.waxHolding = null;
      this.heatHolding = null;

      this.mountHud();
      this.mountModal();
      this.mountCMenu();
      this.renderHud();
    }

    getPuzzle(pid) {
      return PUZZLES.find(p => p.id === pid) || PUZZLES[0];
    }

    mountHud() {
      const mount = document.getElementById('au-hud-root');
      if (!mount) return;
      mount.innerHTML = `
        <div class="au-hud-bar">
          <div class="au-progress-wrap">
            <span class="au-progress-label" id="au-prog-lbl">TASK 0 / 16</span>
            <div class="au-progress-track"><div class="au-progress-fill" id="au-prog-fill" style="width:0%"></div></div>
          </div>
          <div class="au-radio-banner" id="au-radio-banner">📡 C-무전 대기 중 · <kbd>C</kbd> 키로 20토큰 무전 휠 열기</div>
          <div style="display:flex;gap:5px;align-items:center;flex-wrap:wrap" id="au-role-pills"></div>
        </div>
        <div class="au-quick-strip" id="au-quick-strip" aria-label="16개 퍼즐 즉시 시연 셀렉터"></div>
      `;
    }

    mountModal() {
      let bd = document.getElementById('au-backdrop');
      if (!bd) {
        bd = document.createElement('div');
        bd.id = 'au-backdrop';
        bd.className = 'au-backdrop';
        bd.innerHTML = `<div class="au-modal" id="au-modal" role="dialog" aria-modal="true"></div>`;
        document.body.appendChild(bd);
        bd.addEventListener('click', (e) => {
          if (e.target === bd) this.closeModal();
        });
      }
      this.bd = bd;
      this.modalEl = document.getElementById('au-modal');
    }

    mountCMenu() {
      let fab = document.getElementById('au-c-fab');
      if (!fab) {
        fab = document.createElement('button');
        fab.id = 'au-c-fab';
        fab.className = 'au-c-fab';
        fab.innerHTML = `📡 [C] 무전 휠 <span style="font-size:11px;color:#AAB8C2">(20토큰)</span>`;
        document.body.appendChild(fab);
        fab.addEventListener('click', () => this.toggleCMenu());
      }
      let panel = document.getElementById('au-c-panel');
      if (!panel) {
        panel = document.createElement('div');
        panel.id = 'au-c-panel';
        panel.className = 'au-cmenu-panel';
        document.body.appendChild(panel);
      }
      this.cFab = fab;
      this.cPanel = panel;
      window.addEventListener('keydown', (e) => {
        if (e.target.closest('input,select,textarea')) return;
        if (e.key === 'Escape') {
          if (this.cOpen) this.toggleCMenu(false);
          else if (this.modalOpen) this.closeModal();
        } else if ((e.key === 'c' || e.key === 'C') && !e.repeat) {
          this.toggleCMenu();
        }
      });
    }

    toggleCMenu(force) {
      this.cOpen = force !== undefined ? force : !this.cOpen;
      this.cPanel.classList.toggle('open', this.cOpen);
      this.cFab.style.display = this.cOpen ? 'none' : 'flex';
      if (this.cOpen) this.renderCMenu();
    }

    renderCMenu() {
      const r = ROLES[this.activeRole];
      const p = this.getPuzzle(this.activePid);
      const selHtml = this.cSel.length
        ? this.cSel.map(id => this.tokenPill(id)).join(' + ')
        : '<span style="color:#8C9BA6;font-size:12px">아래 20개 토큰 중 1~2개를 클릭해 조합하세요</span>';
      this.cPanel.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <strong style="color:${r.color};font-size:13px">📡 C-Menu 2.0 · 발신자: ${r.name}</strong>
          <button class="au-close-x" style="width:26px;height:26px;font-size:13px" id="au-c-close">✕</button>
        </div>
        <div style="background:#0E1318;border:2px solid #0B0E13;padding:6px 8px;border-radius:6px;display:flex;align-items:center;justify-content:space-between;gap:6px;flex-wrap:wrap">
          <div style="display:flex;gap:4px;align-items:center;flex-wrap:wrap">${selHtml}</div>
          <div style="display:flex;gap:4px">
            <button class="au-btn" style="padding:4px 8px;font-size:11px" id="au-c-clear">비움</button>
            <button class="au-btn primary" style="padding:4px 10px;font-size:11px" id="au-c-send" ${this.cSel.length ? '' : 'disabled'}>발신</button>
          </div>
        </div>
        <div style="max-height:52vh;overflow:auto;margin-top:6px">
          ${C_CATEGORIES.map(cat => `
            <div style="margin-top:6px">
              <div style="font:800 11px sans-serif;color:${cat.color}">${cat.label}</div>
              <div class="au-c-grid">
                ${cat.tokens.map(t => `
                  <button class="au-c-tok ${this.cSel.includes(t.id) ? 'sel' : ''}" data-ctok="${t.id}">
                    <span style="font-size:15px;color:${t.color}">${t.glyph}</span>
                    <span style="font-weight:700;color:#EAF1F6">${t.label}</span>
                  </button>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>
        <div style="margin-top:8px;padding-top:8px;border-top:2px solid #0B0E13;display:flex;justify-content:space-between;align-items:center;gap:6px">
          <span style="font-size:11px;color:#93A4B2">${p.code} 권장 신호 빠른 발신:</span>
          <button class="au-btn amber" style="padding:4px 9px;font-size:11px" id="au-c-preset">정답 패킷 테스트 발신</button>
        </div>
      `;
      this.cPanel.querySelector('#au-c-close').onclick = () => this.toggleCMenu(false);
      this.cPanel.querySelector('#au-c-clear').onclick = () => { this.cSel = []; this.renderCMenu(); };
      this.cPanel.querySelector('#au-c-send').onclick = () => {
        if (!this.cSel.length) return;
        this.sendRadio(this.activeRole, [...this.cSel]);
        this.cSel = [];
        this.renderCMenu();
      };
      this.cPanel.querySelector('#au-c-preset').onclick = () => {
        for (const pkt of p.answerTokens) this.sendRadio(p.helperRoles[0] || 'maria', pkt);
        this.renderCMenu();
      };
      this.cPanel.querySelectorAll('[data-ctok]').forEach(btn => {
        btn.onclick = () => {
          const tid = btn.dataset.ctok;
          if (this.cSel.includes(tid)) this.cSel = this.cSel.filter(x => x !== tid);
          else {
            if (this.cSel.length >= 2) this.cSel.shift();
            this.cSel.push(tid);
          }
          this.renderCMenu();
        };
      });
    }

    tokenPill(tid) {
      const t = TOKENS_BY_ID[tid];
      if (!t) return '';
      return `<span class="au-tok-pill" style="color:${t.color}">${t.glyph} ${t.label}</span>`;
    }

    sendRadio(roleId, tokIds) {
      const r = ROLES[roleId] || ROLES.lin;
      this.radioLog.unshift({
        roleId,
        roleName: r.name,
        color: r.color,
        tokIds,
        ts: new Date().toLocaleTimeString('ko-KR', { hour12: false, minute: '2-digit', second: '2-digit' }),
      });
      if (this.radioLog.length > 6) this.radioLog.length = 6;
      // P16 Stage 2 auto-credit COOP_HERE
      if (tokIds.includes('COOP_HERE')) {
        this.states[16].hereSent = true;
      }
      this.renderHud();
      if (this.modalOpen) this.renderModal();
    }

    renderHud() {
      const pct = Math.round((this.solved.size / 16) * 100);
      const lbl = document.getElementById('au-prog-lbl');
      const fill = document.getElementById('au-prog-fill');
      if (lbl) lbl.textContent = `TASK ${this.solved.size} / 16 (${pct}%)`;
      if (fill) fill.style.width = `${pct}%`;

      const rb = document.getElementById('au-radio-banner');
      if (rb) {
        if (this.radioLog.length) {
          const latest = this.radioLog[0];
          rb.innerHTML = `<span>📡 <strong style="color:${latest.color}">${latest.roleName}</strong></span> ${latest.tokIds.map(id => this.tokenPill(id)).join('<span>+</span>')} <span style="color:#7C8D99;font-size:11px">${latest.ts}</span>`;
        } else {
          rb.innerHTML = `📡 C-무전 대기 중 · <kbd>C</kbd> 키로 20토큰 무전 휠 열기`;
        }
      }

      const rp = document.getElementById('au-role-pills');
      if (rp) {
        rp.innerHTML = Object.values(ROLES).map(r => `
          <button class="au-vtab ${this.activeRole === r.id ? 'active' : ''}" data-role="${r.id}"
            style="${this.activeRole === r.id ? `background:${r.color};color:#0B0E13;` : `border-color:${r.color};color:${r.color};`}">
            ${r.badge} ${r.name}
          </button>
        `).join('');
        rp.querySelectorAll('[data-role]').forEach(btn => {
          btn.onclick = () => { this.activeRole = btn.dataset.role; this.renderHud(); if (this.modalOpen) this.renderModal(); };
        });
      }

      const strip = document.getElementById('au-quick-strip');
      if (strip) {
        strip.innerHTML = PUZZLES.map(p => {
          const r = ROLES[p.mainRole];
          const isSolved = this.solved.has(p.id);
          const isActive = this.activePid === p.id;
          return `
            <button class="au-pq-btn ${isActive ? 'active' : ''} ${isSolved ? 'solved' : ''}" data-pid="${p.id}" title="${p.roomLabel} · ${p.title}">
              <div class="au-pq-top">
                <span style="color:${isSolved ? '#52EFBF' : r.color}">${p.code} · ${p.floor}</span>
                <span>${isSolved ? '✅' : r.badge}</span>
              </div>
              <div class="au-pq-sub">${p.room} · ${p.title}</div>
            </button>
          `;
        }).join('');
        strip.querySelectorAll('[data-pid]').forEach(btn => {
          btn.onclick = () => this.selectAndOpenPuzzle(Number(btn.dataset.pid), true);
        });
      }
    }

    selectAndOpenPuzzle(pid, teleport = true) {
      this.activePid = pid;
      const p = this.getPuzzle(pid);
      this.activeRole = p.mainRole;
      this.viewMode = 'main';
      this.feedback = { msg: `${p.code} 태스크에 접근했습니다. 각 조이스틱·버튼을 직접 조작하세요.`, kind: '' };
      const objs = getPuzzleObjects(pid);
      const target = objs.find(o => o.id === p.focusObj) || objs[0];
      if (teleport && target && this.host?.onJumpToObject) {
        this.host.onJumpToObject(target);
      }
      this.openModal(pid);
    }

    openModal(pid) {
      this.activePid = pid || this.activePid;
      this.modalOpen = true;
      this.bd.classList.add('open');
      this.renderHud();
      this.renderModal();
    }

    closeModal() {
      this.modalOpen = false;
      this.bd.classList.remove('open');
      this.renderHud();
    }

    markSolved(pid, msg) {
      this.solved.add(pid);
      this.feedback = { msg: msg || 'TASK COMPLETED! 박물관 복구 시스템에 등록되었습니다.', kind: 'ok' };
      this.renderHud();
      this.renderModal();
      window.dispatchEvent(new CustomEvent('stranger-puzzle-update', { detail: { pid, solved: true } }));
    }

    setErr(msg) {
      this.feedback = { msg, kind: 'err' };
      this.renderModal();
    }

    setInfo(msg) {
      this.feedback = { msg, kind: '' };
      this.renderModal();
    }

    renderModal() {
      const p = this.getPuzzle(this.activePid);
      const rMain = ROLES[p.mainRole];
      const objs = getPuzzleObjects(p.id);
      const isSolved = this.solved.has(p.id);
      const pinHtml = this.radioLog.slice(0, 2).map(entry =>
        `<span style="display:inline-flex;align-items:center;gap:4px"><strong style="color:${entry.color}">${entry.roleName}:</strong>${entry.tokIds.map(id => this.tokenPill(id)).join('+')}</span>`
      ).join(' <span style="color:#4B5B69">|</span> ') || `<span style="color:#7C8D99">수신된 무전 없음 · 단서 탭에서 [정답 무전 발신] 가능</span>`;

      this.modalEl.innerHTML = `
        <div class="au-modal-head">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <span class="au-rivet"></span>
            <span style="padding:3px 8px;border-radius:4px;background:#0D1217;border:2px solid ${rMain.color};font:900 12px ui-monospace,monospace;color:${rMain.color}">${p.code}</span>
            <span style="font:800 15px sans-serif">${p.title}</span>
            <span style="font:700 12px ui-monospace,monospace;color:#89EFD0">[${p.roomLabel}]</span>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <button class="au-btn" style="padding:5px 10px;font-size:12px" id="au-reset-btn">↺ 초기화</button>
            <button class="au-close-x" id="au-modal-close" title="닫기 (ESC)">✕</button>
          </div>
        </div>
        <div class="au-modal-sub">
          <div class="au-view-tabs">
            <button class="au-vtab ${this.viewMode === 'main' ? 'active' : ''}" data-vmode="main">★ 주도 조작 (${rMain.name})</button>
            <button class="au-vtab ${this.viewMode === 'clue' ? 'active' : ''}" data-vmode="clue">👁 단서·보조 (${p.helperRoles.map(h => ROLES[h].name).join('+')})</button>
            <button class="au-vtab ${this.viewMode === 'coords' ? 'active' : ''}" data-vmode="coords">📐 맵 오브젝트·비율 좌표 (${objs.length})</button>
          </div>
          <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:#9BB0BE">
            <span>아키타입: <strong style="color:#F0F4F8">${p.arch}</strong></span>
          </div>
        </div>
        <div class="au-body">
          <div class="au-pin-radio">
            <span style="font-weight:800;color:#52EFBF">📡 고정 무전:</span>
            ${pinHtml}
          </div>
          <div id="au-stage-area"></div>
          ${this.feedback.msg ? `<div class="au-feedback ${this.feedback.kind}"><span>${this.feedback.msg}</span></div>` : ''}
          ${isSolved ? `<div class="au-stamp-clear">✔ TASK COMPLETED! · ${p.code} 복구 완료 (${this.solved.size}/16)</div>` : ''}
        </div>
      `;

      this.modalEl.querySelector('#au-modal-close').onclick = () => this.closeModal();
      this.modalEl.querySelector('#au-reset-btn').onclick = () => {
        this.states[p.id] = initialStates()[p.id];
        this.solved.delete(p.id);
        this.feedback = { msg: `${p.code} 상태를 초기화했습니다.`, kind: '' };
        this.renderHud();
        this.renderModal();
      };
      this.modalEl.querySelectorAll('[data-vmode]').forEach(btn => {
        btn.onclick = () => { this.viewMode = btn.dataset.vmode; this.renderModal(); };
      });

      const stage = this.modalEl.querySelector('#au-stage-area');
      if (this.viewMode === 'clue') {
        this.renderClueView(stage, p);
      } else if (this.viewMode === 'coords') {
        this.renderCoordsView(stage, p, objs);
      } else {
        this.renderPuzzleBoard(stage, p);
      }
    }

    renderClueView(stage, p) {
      const helpers = p.helperRoles.map(id => ROLES[id]);
      stage.innerHTML = `
        <div class="au-board">
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px">
            <div>
              <span style="font:800 13px sans-serif;color:${helpers[0].color}">${helpers.map(h => h.badge + ' ' + h.name).join(' · ')} 전용 뷰</span>
              <div style="font:700 15px sans-serif;margin-top:2px">${p.clueTitle}</div>
            </div>
            <button class="au-btn primary" id="au-send-clue-pkt">📡 C-무전 정답 패킷 발신</button>
          </div>
          ${p.clueHtml}
          <div style="margin-top:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <span style="font-size:12px;color:#9BB0BE">발신할 핵심 패킷:</span>
            ${p.answerTokens.map(pkt => pkt.map(t => this.tokenPill(t)).join('+')).join(' <span style="color:#667"> / </span> ')}
          </div>
        </div>
      `;
      stage.querySelector('#au-send-clue-pkt').onclick = () => {
        for (const pkt of p.answerTokens) this.sendRadio(p.helperRoles[0], pkt);
        this.setInfo('단서 무전 패킷을 상단 HUD와 조작 모달에 고정 발신했습니다!');
      };
    }

    renderCoordsView(stage, p, objs) {
      stage.innerHTML = `
        <div class="au-board">
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:6px">
            <strong>📐 맵 실비율 2048×1664px (캐릭터 30×50px · 발판 14×8px) 오브젝트 명세</strong>
            <span style="font:700 12px monospace;color:#52EFBF">행을 클릭하면 캐릭터가 해당 오브젝트로 이동합니다</span>
          </div>
          <table class="au-obj-table">
            <thead>
              <tr>
                <th>오브젝트 ID / 이름</th>
                <th>층 · 방</th>
                <th>역할 배분</th>
                <th>스프라이트 크기 (x, y, w×h)</th>
                <th>상호작용 위치 (ix, iy)</th>
              </tr>
            </thead>
            <tbody>
              ${objs.map(o => `
                <tr class="au-obj-row" data-jump-oid="${o.id}">
                  <td><strong style="color:#89EFD0">${o.id}</strong><br><span style="color:#C2CFD8">${o.name}</span></td>
                  <td><code>${o.floor} · ${o.room}</code></td>
                  <td>${o.role || '-'}</td>
                  <td><code>(${o.x}, ${o.y}) ${o.width}×${o.height}px</code></td>
                  <td><code>${o.interact ? `(${o.interact[0]}, ${o.interact[1]})` : '-'}</code></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
      stage.querySelectorAll('[data-jump-oid]').forEach(tr => {
        tr.onclick = () => {
          const obj = objs.find(o => o.id === tr.dataset.jumpOid);
          if (obj && this.host?.onJumpToObject) {
            this.host.onJumpToObject(obj);
            this.closeModal();
          }
        };
      });
    }

    renderPuzzleBoard(stage, p) {
      const s = this.states[p.id];
      const handlers = {
        1: () => this.boardP01(stage, p, s),
        2: () => this.boardP02(stage, p, s),
        3: () => this.boardP03(stage, p, s),
        4: () => this.boardP04(stage, p, s),
        5: () => this.boardP05(stage, p, s),
        6: () => this.boardP06(stage, p, s),
        7: () => this.boardP07(stage, p, s),
        8: () => this.boardP08(stage, p, s),
        9: () => this.boardP09(stage, p, s),
        10: () => this.boardP10(stage, p, s),
        11: () => this.boardP11(stage, p, s),
        12: () => this.boardP12(stage, p, s),
        13: () => this.boardP13(stage, p, s),
        14: () => this.boardP14(stage, p, s),
        15: () => this.boardP15(stage, p, s),
        16: () => this.boardP16(stage, p, s),
      };
      (handlers[p.id] || (() => {}))();
    }

    // P01: Concentric compass rings
    boardP01(stage, p, s) {
      const dirs = ['↑ N 북', '→ E 동', '↓ S 남', '← W 서'];
      const syms = ['☀ 생활사', '★ 역사', '🌊 도시', '⛰ 공예'];
      const aligned = (s.outerDeg % 360 === 0) && (s.innerDeg % 360 === 0);
      stage.innerHTML = `
        <div class="au-board" style="display:grid;grid-template-columns:minmax(220px,260px) 1fr;gap:16px;align-items:center">
          <div style="display:flex;justify-content:center">
            <svg viewBox="0 0 240 240" width="230" height="230">
              <circle cx="120" cy="120" r="108" fill="#1C242E" stroke="#C89D54" stroke-width="6"/>
              <g transform="rotate(${s.outerDeg} 120 120)">
                <circle cx="120" cy="120" r="96" fill="none" stroke="#52EFBF" stroke-width="2" stroke-dasharray="6 4"/>
                <text x="120" y="30" text-anchor="middle" fill="#FFD86B" font-size="14" font-weight="800">${dirs[0]}</text>
                <text x="210" y="125" text-anchor="middle" fill="#D5DFE8" font-size="12" font-weight="700">${dirs[1]}</text>
                <text x="120" y="216" text-anchor="middle" fill="#7CD8FF" font-size="12" font-weight="700">${dirs[2]}</text>
                <text x="32" y="125" text-anchor="middle" fill="#D5DFE8" font-size="12" font-weight="700">${dirs[3]}</text>
              </g>
              <g transform="rotate(${s.innerDeg} 120 120)">
                <circle cx="120" cy="120" r="64" fill="#25313E" stroke="#C89D54" stroke-width="4"/>
                <text x="120" y="72" text-anchor="middle" fill="#E6C886" font-size="12" font-weight="800">${syms[0]}</text>
                <text x="166" y="124" text-anchor="middle" fill="#91A8FF" font-size="11" font-weight="700">${syms[1]}</text>
                <text x="120" y="176" text-anchor="middle" fill="#7CD8FF" font-size="12" font-weight="700">${syms[2]}</text>
                <text x="74" y="124" text-anchor="middle" fill="#D49B6A" font-size="11" font-weight="700">${syms[3]}</text>
              </g>
              <circle cx="120" cy="120" r="22" fill="${s.locked ? '#27BA74' : (aligned ? '#1E7A5D' : '#3C4A59')}" stroke="#0B0E13" stroke-width="4"/>
              <polygon points="120,8 113,20 127,20" fill="#FF6E6E"/>
              <text x="120" y="124" text-anchor="middle" fill="#fff" font-size="11" font-weight="900">${s.locked ? 'OPEN' : 'PIN'}</text>
            </svg>
          </div>
          <div style="display:grid;gap:10px">
            <div style="background:#1D252F;border:2px solid #0B0E13;padding:10px;border-radius:8px">
              <div style="font:800 13px sans-serif;color:#52EFBF">① 외륜 방위 베젤 (${s.outerDeg}°)</div>
              <div style="display:flex;gap:8px;margin-top:6px">
                <button class="au-btn" id="p1-ol">↺ -90°</button>
                <button class="au-btn" id="p1-or">↻ +90°</button>
              </div>
            </div>
            <div style="background:#1D252F;border:2px solid #0B0E13;padding:10px;border-radius:8px">
              <div style="font:800 13px sans-serif;color:#E6C886">② 내륜 전시관 문양 (${s.innerDeg}°)</div>
              <div style="display:flex;gap:8px;margin-top:6px">
                <button class="au-btn" id="p1-il">↺ -90°</button>
                <button class="au-btn" id="p1-ir">↻ +90°</button>
              </div>
            </div>
            <button class="au-btn primary" id="p1-lock">🔓 중앙 황동 핀 잠금 해제 (4대 전시관 개방)</button>
          </div>
        </div>
      `;
      stage.querySelector('#p1-ol').onclick = () => { s.outerDeg = (s.outerDeg + 270) % 360; this.renderModal(); };
      stage.querySelector('#p1-or').onclick = () => { s.outerDeg = (s.outerDeg + 90) % 360; this.renderModal(); };
      stage.querySelector('#p1-il').onclick = () => { s.innerDeg = (s.innerDeg + 270) % 360; this.renderModal(); };
      stage.querySelector('#p1-ir').onclick = () => { s.innerDeg = (s.innerDeg + 90) % 360; this.renderModal(); };
      stage.querySelector('#p1-lock').onclick = () => {
        if (s.outerDeg === 0 && s.innerDeg === 0) {
          s.locked = true;
          this.markSolved(1, '로비 나침반 정렬 완료! 1F 4대 전시관의 황동 잠금이 해제되었습니다.');
        } else {
          this.setErr(`방위(${s.outerDeg}°) 또는 문양(${s.innerDeg}°)이 마리아의 방명록 기준(0°)과 다릅니다.`);
        }
      };
    }

    // P02: Bahay Kubo 3-tier cross-section drag/click
    boardP02(stage, p, s) {
      const cards = [
        { id: 'grain_jar', label: '🌾 건조 곡식 단지', right: 'roof' },
        { id: 'basket', label: '🧺 대나무 직조 바구니', right: 'floor' },
        { id: 'mortar', label: '🪨 돌절구', right: 'stilt' },
        { id: 'lamp', label: '🏮 등유 램프 (미끼)', right: 'none' },
      ];
      const tiers = [
        { id: 'roof', name: '① 지붕 다락 (Bubong · ☀ 태양)' },
        { id: 'floor', name: '② 대나무 마루 (Sala · 🌊 파도)' },
        { id: 'stilt', name: '③ 고상 기둥 아래 (Silong · ⛰ 산맥)' },
      ];
      const placedIds = Object.values(s.slots);
      stage.innerHTML = `
        <div class="au-board" style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div>
            <div style="font:800 13px sans-serif;color:#7CD8FF;margin-bottom:8px">바하이 쿠보 3층위 가옥 단면 (카드 클릭 → 층위 클릭)</div>
            <div style="display:grid;gap:8px;background:#211911;padding:12px;border:3px solid #6E522B;border-radius:10px">
              ${tiers.map(t => {
                const cid = s.slots[t.id];
                const card = cards.find(c => c.id === cid);
                return `<div class="au-slot-box ${cid ? 'filled' : ''}" data-tier="${t.id}">
                  <span style="font:700 12px sans-serif">${t.name}</span>
                  <strong>${card ? card.label : '빈 슬롯 (클릭해 배치)'}</strong>
                </div>`;
              }).join('')}
            </div>
          </div>
          <div style="display:flex;flex-direction:column;justify-content:space-between;gap:10px">
            <div>
              <div style="font:800 13px sans-serif;color:#E6C886;margin-bottom:8px">생활 유물 트레이 (드래그 또는 클릭 선택)</div>
              <div style="display:grid;gap:7px">
                ${cards.map(c => {
                  const used = placedIds.includes(c.id);
                  return `<button class="au-card-chip ${s.picked === c.id ? 'picked' : ''}" draggable="true" data-card="${c.id}" ${used ? 'disabled style="opacity:.4"' : ''}>${c.label}</button>`;
                }).join('')}
              </div>
            </div>
            <button class="au-btn primary" id="p2-check">✔ 가옥 단면 조립 확정</button>
          </div>
        </div>
      `;
      stage.querySelectorAll('[data-card]').forEach(btn => {
        btn.onclick = () => { s.picked = btn.dataset.card; this.renderModal(); };
        btn.ondragstart = (e) => { s.picked = btn.dataset.card; e.dataTransfer.setData('text/plain', btn.dataset.card); };
      });
      stage.querySelectorAll('[data-tier]').forEach(box => {
        const place = (cid) => {
          if (!cid) { s.slots[box.dataset.tier] = null; this.renderModal(); return; }
          for (const k of Object.keys(s.slots)) if (s.slots[k] === cid) s.slots[k] = null;
          s.slots[box.dataset.tier] = cid;
          s.picked = null;
          this.renderModal();
        };
        box.onclick = () => place(s.picked);
        box.ondragover = (e) => e.preventDefault();
        box.ondrop = (e) => { e.preventDefault(); place(e.dataTransfer.getData('text/plain') || s.picked); };
      });
      stage.querySelector('#p2-check').onclick = () => {
        if (s.slots.roof === 'grain_jar' && s.slots.floor === 'basket' && s.slots.stilt === 'mortar') {
          this.markSolved(2, '바하이 쿠보 3층위 생활 유물 배치 완료! 모형 가옥에 따뜻한 조명이 켜졌습니다.');
        } else {
          if (s.slots.roof !== 'grain_jar') s.slots.roof = null;
          if (s.slots.floor !== 'basket') s.slots.floor = null;
          if (s.slots.stilt !== 'mortar') s.slots.stilt = null;
          this.setErr('일치하지 않는 층위의 유물만 트레이로 돌려보냈습니다. Bubong-Sala-Silong 순서를 확인하세요!');
        }
      };
    }

    // P03: Manunggul jar turntable + spirit boat lid tilt
    boardP03(stage, p, s) {
      const aligned = s.turntableDeg % 360 === 180 && s.lidTiltDeg === 0;
      stage.innerHTML = `
        <div class="au-board" style="display:grid;grid-template-columns:220px 1fr;gap:14px;align-items:center">
          <div style="background:#0F141A;border:3px solid #0B0E13;border-radius:10px;padding:12px;text-align:center">
            <svg viewBox="0 0 180 180" width="190" height="190">
              <ellipse cx="90" cy="146" rx="68" ry="16" fill="#2A3642" stroke="#7CD8FF" stroke-width="2"/>
              <g transform="translate(0 ${s.seated ? 4 : -14}) rotate(${s.lidTiltDeg} 90 66)">
                <path d="M56 76 Q90 42 124 76 Z" fill="#9E6242" stroke="#0B0E13" stroke-width="3"/>
                <path d="M70 52 L82 40 L102 42 L114 52" fill="none" stroke="#E6C886" stroke-width="4" stroke-linecap="round"/>
                <circle cx="80" cy="40" r="4" fill="#E6C886"/><circle cx="102" cy="40" r="4" fill="#E6C886"/>
              </g>
              <ellipse cx="90" cy="112" rx="44" ry="38" fill="#8B5438" stroke="#0B0E13" stroke-width="3"/>
              <path d="M${56 + Math.sin(s.turntableDeg * Math.PI / 180) * 14} 110 Q90 ${100 + Math.cos(s.turntableDeg * Math.PI / 180) * 10} ${124 + Math.sin(s.turntableDeg * Math.PI / 180) * 14} 110"
                fill="none" stroke="${s.turntableDeg === 180 ? '#52EFBF' : '#FFB86B'}" stroke-width="4"/>
              <text x="90" y="168" text-anchor="middle" fill="#89EFD0" font-size="11" font-weight="800">${s.turntableDeg}° · 틸트 ${s.lidTiltDeg}°</text>
            </svg>
          </div>
          <div style="display:grid;gap:12px">
            <div>
              <label style="font:800 13px sans-serif;color:#7CD8FF">① 원통 턴테이블 각도: <strong>${s.turntableDeg}°</strong> (목표 180°)</label>
              <div style="display:flex;gap:8px;margin-top:6px;align-items:center">
                <button class="au-btn" id="p3-rot-l">↺ -30°</button>
                <input type="range" min="0" max="330" step="30" value="${s.turntableDeg}" id="p3-rot-r" style="flex:1"/>
                <button class="au-btn" id="p3-rot-p">↻ +30°</button>
              </div>
            </div>
            <div>
              <label style="font:800 13px sans-serif;color:#FFB86B">② 영혼의 배 뚜껑 수평 기울기: <strong>${s.lidTiltDeg}°</strong> (목표 0°)</label>
              <div style="display:flex;gap:8px;margin-top:6px;align-items:center">
                <button class="au-btn" id="p3-tl">-5°</button>
                <input type="range" min="-30" max="30" step="5" value="${s.lidTiltDeg}" id="p3-tr" style="flex:1"/>
                <button class="au-btn" id="p3-tp">+5°</button>
              </div>
            </div>
            <button class="au-btn primary" id="p3-seat">${aligned ? '✨ 뚜껑 안착 결합 (준비 완료)' : '🔒 뚜껑 안착 결합 시도'}</button>
          </div>
        </div>
      `;
      stage.querySelector('#p3-rot-l').onclick = () => { s.turntableDeg = (s.turntableDeg + 330) % 360; this.renderModal(); };
      stage.querySelector('#p3-rot-p').onclick = () => { s.turntableDeg = (s.turntableDeg + 30) % 360; this.renderModal(); };
      stage.querySelector('#p3-rot-r').oninput = (e) => { s.turntableDeg = Number(e.target.value); this.renderModal(); };
      stage.querySelector('#p3-tl').onclick = () => { s.lidTiltDeg = Math.max(-30, s.lidTiltDeg - 5); this.renderModal(); };
      stage.querySelector('#p3-tp').onclick = () => { s.lidTiltDeg = Math.min(30, s.lidTiltDeg + 5); this.renderModal(); };
      stage.querySelector('#p3-tr').oninput = (e) => { s.lidTiltDeg = Number(e.target.value); this.renderModal(); };
      stage.querySelector('#p3-seat').onclick = () => {
        if (aligned) {
          s.seated = true;
          this.markSolved(3, '마눙굴 항아리 톱니(180°)와 영혼의 배 뚜껑(0°) 결합 복원 완료!');
        } else {
          this.setErr(`톱니(현재 ${s.turntableDeg}° → 180°) 또는 뚜껑 기울기(현재 ${s.lidTiltDeg}° → 0°)가 어긋나 톱니가 물리지 않습니다.`);
        }
      };
    }

    // P04: 2D Map Strait Pins x Timeline Wire Linker (Among Us Wires style!)
    boardP04(stage, p, s) {
      const leftNodes = [
        { id: '1521', label: '① 1521 막탄 항해', y: 40, color: '#FFD86B' },
        { id: '1898', label: '② 1898 말롤로스 헌법', y: 110, color: '#52EFBF' },
        { id: '1946', label: '③ 1946 공화국 독립', y: 180, color: '#7CD8FF' },
      ];
      const rightNodes = [
        { id: 'manila_north', label: '마닐라 북부 (북 ↑)', y: 40 },
        { id: 'malolos', label: '말롤로스 성당 (서 ←)', y: 110 },
        { id: 'visayas', label: '비사야 해협 (동남)', y: 180 },
      ];
      const wires = leftNodes.map(ln => {
        const rid = s.links[ln.id];
        const rn = rightNodes.find(r => r.id === rid);
        return rn ? `<line x1="8" y1="${ln.y}" x2="212" y2="${rn.y}" stroke="${ln.color}" stroke-width="5" stroke-linecap="round"/>` : '';
      }).join('');
      stage.innerHTML = `
        <div class="au-board">
          <div style="font:800 13px sans-serif;color:#E6C886;margin-bottom:10px">왼쪽 연표 노드를 클릭한 뒤 오른쪽 해협 핀을 클릭해 3개의 케이블을 결선하세요</div>
          <div style="display:grid;grid-template-columns:1fr 220px 1fr;gap:8px;align-items:center">
            <div style="display:grid;gap:22px">
              ${leftNodes.map(n => `<button class="au-btn" data-ln="${n.id}" style="border-color:${s.selectedLeft === n.id ? '#fff' : n.color};background:${s.selectedLeft === n.id ? '#364654' : '#202A34'};text-align:left">${n.label}</button>`).join('')}
            </div>
            <svg viewBox="0 0 220 220" width="220" height="220" style="background:#0F151B;border:2px solid #2A3542;border-radius:8px">${wires}</svg>
            <div style="display:grid;gap:22px">
              ${rightNodes.map(r => `<button class="au-btn" data-rn="${r.id}" style="text-align:right">${r.label}</button>`).join('')}
            </div>
          </div>
          <div style="margin-top:12px;display:flex;justify-content:flex-end">
            <button class="au-btn primary" id="p4-verify">✔ 3대 연표 결선 확인</button>
          </div>
        </div>
      `;
      stage.querySelectorAll('[data-ln]').forEach(b => b.onclick = () => { s.selectedLeft = b.dataset.ln; this.renderModal(); });
      stage.querySelectorAll('[data-rn]').forEach(b => b.onclick = () => {
        if (!s.selectedLeft) { this.setErr('먼저 왼쪽 연표(1521·1898·1946) 버튼을 선택하세요.'); return; }
        s.links[s.selectedLeft] = b.dataset.rn;
        s.selectedLeft = null;
        this.renderModal();
      });
      stage.querySelector('#p4-verify').onclick = () => {
        if (s.links['1521'] === 'visayas' && s.links['1898'] === 'malolos' && s.links['1946'] === 'manila_north') {
          this.markSolved(4, '군도 해협과 3대 독립 연표 크로스 결선 완벽 일치!');
        } else {
          this.setErr('잘못 연결된 노선이 있습니다. 린의 방위 신호(2번 말롤로스=서←, 3번 마닐라=북↑)를 대조하세요.');
        }
      };
    }

    // P05: Ifugao Loom 3-heddle pedal + 3-color shuttle weave
    boardP05(stage, p, s) {
      const shuttles = [
        { id: 'gold', label: '☀ 황금 실 (1줄)', hex: '#E6C886' },
        { id: 'crimson', label: '⚡ 진홍 실 (2줄)', hex: '#E35B5B' },
        { id: 'cyan', label: '🌊 청록 실 (3줄)', hex: '#52D7E8' },
      ];
      stage.innerHTML = `
        <div class="au-board" style="display:grid;gap:12px">
          <div style="background:#23180E;border:3px solid #6E522B;border-radius:8px;padding:10px">
            <div style="font:800 12px sans-serif;color:#E6C886;margin-bottom:6px">이푸가오 수직 베틀 직조 판 (먼저 페달을 밟아 줄을 연 뒤 해당 색 실을 끼우세요)</div>
            <div style="display:grid;gap:6px">
              ${[0, 1, 2].map(i => {
                const col = shuttles.find(x => x.id === s.rows[i]);
                return `<div style="display:grid;grid-template-columns:80px 1fr 90px;gap:8px;align-items:center">
                  <button class="au-btn ${s.heddleOpen[i] ? 'primary' : ''}" data-ped="${i}" style="padding:6px">페달 ${i + 1} ${s.heddleOpen[i] ? '개방됨' : '닫힘'}</button>
                  <div style="height:26px;border-radius:4px;border:2px solid #0B0E13;background:${col ? col.hex : (s.heddleOpen[i] ? '#2C3846' : '#161B21')};display:flex;align-items:center;justify-content:center;font:800 12px sans-serif;color:${col ? '#0B0E13' : '#9AA7B4'}">
                    ${col ? col.label + ' 직조됨' : (s.heddleOpen[i] ? '날실 열림 — 아래 실을 선택!' : '페달로 줄을 먼저 여세요')}
                  </div>
                  <button class="au-btn" data-rew="${i}" style="padding:5px;font-size:11px">↺ 되감기</button>
                </div>`;
              }).join('')}
            </div>
          </div>
          <div style="display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap">
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              ${shuttles.map(sh => `<button class="au-btn" data-sh="${sh.id}" style="background:${sh.hex};color:#0B0E13">🧵 ${sh.label} 왕복</button>`).join('')}
            </div>
            <button class="au-btn primary" id="p5-done">✔ 직물 완성 검증</button>
          </div>
        </div>
      `;
      stage.querySelectorAll('[data-ped]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.ped);
        s.heddleOpen = s.heddleOpen.map((_, idx) => idx === i ? !s.heddleOpen[i] : false);
        this.renderModal();
      });
      stage.querySelectorAll('[data-rew]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.rew);
        s.rows[i] = null;
        this.renderModal();
      });
      stage.querySelectorAll('[data-sh]').forEach(b => b.onclick = () => {
        const openIdx = s.heddleOpen.findIndex(Boolean);
        if (openIdx === -1) { this.setErr('페달(1~3) 중 하나를 밟아 실틈을 먼저 열어 주세요!'); return; }
        s.rows[openIdx] = b.dataset.sh;
        this.renderModal();
      });
      stage.querySelector('#p5-done').onclick = () => {
        if (s.rows[0] === 'gold' && s.rows[1] === 'crimson' && s.rows[2] === 'cyan') {
          this.markSolved(5, '이푸가오 3색 씨실·날실 직조 완료! 전통 직물 전시가 복원되었습니다.');
        } else {
          this.setErr('상단(황금)→중단(진홍)→하단(청록) 순서가 어긋났습니다. 잘못된 줄만 되감기 후 다시 엮어 보세요.');
        }
      };
    }

    // P06: 1910 Manila Tranvia Switches & Optical Viewfinder
    boardP06(stage, p, s) {
      const routeOk = s.switches[0] === 'B' && s.switches[1] === 'B' && s.switches[2] === 'A';
      stage.innerHTML = `
        <div class="au-board" style="display:grid;gap:12px">
          <svg viewBox="0 0 460 120" style="width:100%;height:110px;background:#0F151B;border:2px solid #2A3542;border-radius:8px">
            <text x="16" y="20" fill="#89EFD0" font-size="11" font-weight="700">Intramuros 출발</text>
            <text x="215" y="108" fill="#E6C886" font-size="11" font-weight="700">2번 비논도 우회선</text>
            <text x="360" y="20" fill="#52EFBF" font-size="11" font-weight="700">동→ 파시그강 도개교</text>
            <path d="M20 40 L140 40 L290 40 L430 40" stroke="#303D4A" stroke-width="6" fill="none"/>
            <path d="M140 40 L200 84 L320 84 L360 40" stroke="#303D4A" stroke-width="6" fill="none"/>
            <path d="${routeOk ? 'M20 40 L140 40 L200 84 L320 84 L360 40 L430 40' : 'M20 40 L140 40'}" stroke="${routeOk ? '#52EFBF' : '#FF6E6E'}" stroke-width="6" fill="none" stroke-linecap="round"/>
            <circle cx="${s.dispatched && routeOk ? 420 : 28}" cy="40" r="9" fill="#FFD86B" stroke="#0B0E13" stroke-width="2"/>
          </svg>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
            ${[0, 1, 2].map(i => `
              <button class="au-btn ${s.switches[i] === (i < 2 ? 'B' : 'A') ? 'amber' : ''}" data-sw="${i}">
                레버 S${i + 1}: <strong>${s.switches[i]} 분기</strong>
              </button>
            `).join('')}
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
            <div style="display:flex;align-items:center;gap:6px">
              <span style="font:800 12px sans-serif;color:#7CD8FF">광학 뷰파인더:</span>
              ${['N', 'E', 'S', 'W'].map(d => `<button class="au-btn ${s.dir === d ? 'primary' : ''}" data-vdir="${d}" style="padding:6px 10px">${{ N: '북↑', E: '동→', S: '남↓', W: '서←' }[d]}</button>`).join('')}
            </div>
            <button class="au-btn primary" id="p6-go">🚋 1910 전차 출발 (Dispatch)</button>
          </div>
        </div>
      `;
      stage.querySelectorAll('[data-sw]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.sw);
        s.switches[i] = s.switches[i] === 'A' ? 'B' : 'A';
        this.renderModal();
      });
      stage.querySelectorAll('[data-vdir]').forEach(b => b.onclick = () => { s.dir = b.dataset.vdir; this.renderModal(); });
      stage.querySelector('#p6-go').onclick = () => {
        if (routeOk && s.dir === 'E') {
          s.dispatched = true;
          this.markSolved(6, '전차가 2번 우회선로를 따라 동쪽 파시그강 도개교를 무사히 건넜습니다!');
        } else {
          this.setErr('선로 조합(S1=B, S2=B, S3=A) 또는 뷰파인더 방위(동 →)가 맞지 않아 전차가 완충기에 정지했습니다.');
        }
      };
    }

    // P07: B1 Water Main 3 Handwheel Gauges (Coupled Hydraulics!)
    boardP07(stage, p, s) {
      const [v1, v2, v3] = s.valves;
      const p1 = Math.round(50 + 0.4 * (100 - v1) - 0.2 * v3);
      const p2 = Math.round(40 + 0.4 * v2);
      const p3 = Math.round(20 + 0.4 * v3);
      const psis = [p1, p2, p3];
      const allGreen = psis.every(v => v >= 55 && v <= 65);
      stage.innerHTML = `
        <div class="au-board" style="display:grid;gap:12px">
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
            ${[0, 1, 2].map(i => {
              const psi = psis[i];
              const ok = psi >= 55 && psi <= 65;
              const ang = -110 + Math.min(120, Math.max(0, psi)) * 1.83;
              return `<div style="background:#10151B;border:3px solid ${ok ? '#52EFBF' : '#394654'};border-radius:10px;padding:10px;text-align:center">
                <div style="font:800 12px monospace;color:${ok ? '#52EFBF' : '#FFB86B'}">구역 ${i + 1} · ${psi} PSI</div>
                <svg viewBox="0 0 120 74" width="110" height="68" style="margin:4px auto">
                  <path d="M18 62 A42 42 0 1 1 102 62" fill="none" stroke="#2D3844" stroke-width="10"/>
                  <path d="M48 21 A42 42 0 0 1 72 21" fill="none" stroke="#52EFBF" stroke-width="10"/>
                  <line x1="60" y1="60" x2="60" y2="24" stroke="#FF6E6E" stroke-width="3" transform="rotate(${ang} 60 60)" stroke-linecap="round"/>
                  <circle cx="60" cy="60" r="6" fill="#C89D54"/>
                </svg>
                <div style="font:700 12px monospace;margin:4px 0">밸브 ${i + 1} 개방: <strong>${s.valves[i]}%</strong></div>
                <div style="display:flex;justify-content:center;gap:6px">
                  <button class="au-btn" data-vd="${i}">-25%</button>
                  <button class="au-btn" data-vu="${i}">+25%</button>
                </div>
              </div>`;
            }).join('')}
          </div>
          <button class="au-btn primary" id="p7-lock">${allGreen ? '✔ 전 구역 60 PSI 녹색 존 안착 — 배수 완료!' : '⚙ 수압 평형 검증 (55~65 PSI)'}</button>
        </div>
      `;
      stage.querySelectorAll('[data-vd]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.vd); s.valves[i] = Math.max(0, s.valves[i] - 25); this.renderModal();
      });
      stage.querySelectorAll('[data-vu]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.vu); s.valves[i] = Math.min(100, s.valves[i] + 25); this.renderModal();
      });
      stage.querySelector('#p7-lock').onclick = () => {
        if (allGreen) this.markSolved(7, 'B1 주 급수관 3구역 모두 60 PSI 평형 달성! 통로 배수가 완료되었습니다.');
        else this.setErr(`현재 수압 [${psis.join(', ')}] PSI. 3구역 모두 55~65 PSI 녹색 대역에 맞추세요 (1:25%, 2:50%, 3:100%).`);
      };
    }

    // P08: B1 Boiler Steam Relief & Dual Pump RPM Sync
    boardP08(stage, p, s) {
      const psiOk = s.boilerPsi >= 70 && s.boilerPsi <= 90;
      const rpmOk = Math.abs(s.pump1Rpm - s.pump2Rpm) <= 30 && s.pump1Rpm >= 1150 && s.pump1Rpm <= 1250;
      stage.innerHTML = `
        <div class="au-board" style="display:grid;gap:12px">
          <div style="background:#10151B;border:2px solid ${psiOk ? '#52EFBF' : '#FF6E6E'};border-radius:8px;padding:10px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
            <div>
              <div style="font:800 13px sans-serif;color:${psiOk ? '#52EFBF' : '#FF6E6E'}">① 보일러 증기 압력: ${s.boilerPsi} PSI (안전 대역 70~90 PSI)</div>
              <div style="width:240px;height:14px;background:#1C232B;border:2px solid #0B0E13;border-radius:4px;margin-top:4px;overflow:hidden">
                <div style="width:${Math.min(100, Math.round(s.boilerPsi / 160 * 100))}%;height:100%;background:${psiOk ? '#52EFBF' : '#FF6E6E'}"></div>
              </div>
            </div>
            <div style="display:flex;gap:6px">
              <button class="au-btn danger" id="p8-bleed">💨 증기 배출 (-15 PSI)</button>
              <button class="au-btn" id="p8-add">+10 PSI</button>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div style="background:#10151B;border:2px solid #2A3542;border-radius:8px;padding:10px">
              <div style="font:800 12px monospace;color:#FFB86B">펌프 1호기: ${s.pump1Rpm} RPM (목표 ~1200)</div>
              <input type="range" min="700" max="1600" step="20" value="${s.pump1Rpm}" id="p8-r1" style="width:100%;margin-top:6px"/>
            </div>
            <div style="background:#10151B;border:2px solid #2A3542;border-radius:8px;padding:10px">
              <div style="font:800 12px monospace;color:#7CD8FF">펌프 2호기: ${s.pump2Rpm} RPM (차이: ${Math.abs(s.pump1Rpm - s.pump2Rpm)} RPM)</div>
              <input type="range" min="700" max="1600" step="20" value="${s.pump2Rpm}" id="p8-r2" style="width:100%;margin-top:6px"/>
            </div>
          </div>
          <button class="au-btn primary" id="p8-sync">⚡ 복식 펌프 위상 동기 잠금</button>
        </div>
      `;
      stage.querySelector('#p8-bleed').onclick = () => { s.boilerPsi = Math.max(50, s.boilerPsi - 15); this.renderModal(); };
      stage.querySelector('#p8-add').onclick = () => { s.boilerPsi = Math.min(160, s.boilerPsi + 10); this.renderModal(); };
      stage.querySelector('#p8-r1').oninput = (e) => { s.pump1Rpm = Number(e.target.value); this.renderModal(); };
      stage.querySelector('#p8-r2').oninput = (e) => { s.pump2Rpm = Number(e.target.value); this.renderModal(); };
      stage.querySelector('#p8-sync').onclick = () => {
        if (psiOk && rpmOk) {
          s.synced = true;
          this.markSolved(8, '보일러 압력 정상(70~90 PSI) & 복식 순환 펌프 1200 RPM 동기 잠금 완료!');
        } else {
          this.setErr('보일러 압력을 70~90 PSI로 낮추고, 두 펌프를 1150~1250 RPM 사이(오차 ±30 이내)로 맞추세요.');
        }
      };
    }

    // P09: B1 Diesel Crank & 3-Bay Switchgear Busbar Interlock
    boardP09(stage, p, s) {
      const busOk = !s.bus[0] && !s.bus[1] && s.bus[2];
      stage.innerHTML = `
        <div class="au-board" style="display:grid;gap:12px">
          <div style="background:#10151B;border:2px solid ${s.genRunning ? '#52EFBF' : '#FFB86B'};border-radius:8px;padding:10px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
            <div>
              <div style="font:800 13px sans-serif;color:#FFB86B">① 비상 디젤 발전기 (${s.genRunning ? '60Hz 정상 가동 중' : `예열 ${s.heat}% / 정지`})</div>
              <div style="font-size:11px;color:#9BB0BE">예열 100% 후 크랭크를 당겨 발전기를 먼저 켜세요.</div>
            </div>
            <div style="display:flex;gap:8px">
              <button class="au-btn amber" id="p9-heat">🔥 코일 예열 (+50%)</button>
              <button class="au-btn primary" id="p9-crank" ${s.heat < 100 ? 'disabled style="opacity:.4"' : ''}>🔑 크랭크 기동</button>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
            ${[0, 1, 2].map(i => `
              <button class="au-btn ${s.bus[i] ? (i < 2 ? 'danger' : 'primary') : ''}" data-bus="${i}">
                베이 ${i + 1} (${i < 2 ? '단락 위험!' : '우회 모선'})<br>
                <strong>${s.bus[i] ? '🔌 ON (투입)' : '⬜ OFF (차단)'}</strong>
              </button>
            `).join('')}
          </div>
          <button class="au-btn primary" id="p9-main">🔴 중앙 로터리 주 차단기 투입 (Main Breaker ON)</button>
        </div>
      `;
      stage.querySelector('#p9-heat').onclick = () => { s.heat = Math.min(100, s.heat + 50); this.renderModal(); };
      stage.querySelector('#p9-crank').onclick = () => { s.genRunning = true; this.setInfo('디젤 발전기 60Hz 기동 성공! 이제 1·2번을 끄고 3번 우회 모선만 켜세요.'); };
      stage.querySelectorAll('[data-bus]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.bus); s.bus[i] = !s.bus[i]; this.renderModal();
      });
      stage.querySelector('#p9-main').onclick = () => {
        if (!s.genRunning) { this.setErr('먼저 디젤 발전기를 예열(100%) 후 크랭크 기동하세요.'); return; }
        if (busOk) {
          s.breaker = true;
          this.markSolved(9, '3번 예비 모선 우회 투입 완료! 박물관 전체 비상 전력이 정식 조명으로 복구되었습니다.');
        } else {
          this.setErr('과전류 트립! 단락된 1·2번 모선을 OFF로 끄고, 3번 예비 우회 모선만 ON 상태로 투입하세요.');
        }
      };
    }

    // P10: B1 Dehumidifier Dew Point + 2-Axis Crane Hoist Grid
    boardP10(stage, p, s) {
      const dewOk = s.rh === 45 && s.temp === 18;
      const puddles = new Set(['2,2', '3,2', '2,3']);
      const targetKey = '4,1';
      let cells = '';
      for (let y = 1; y <= 4; y++) {
        for (let x = 0; x <= 4; x++) {
          const key = `${x},${y}`;
          const isPud = puddles.has(key);
          const isTarget = key === targetKey;
          const isCrane = s.crane[0] === x && s.crane[1] === y;
          const isCrate = s.cratePos[0] === x && s.cratePos[1] === y;
          cells += `<div class="au-cell ${isPud ? 'puddle' : ''} ${isTarget ? 'rack' : ''}">
            ${isCrane ? `<span style="color:#FFD86B">${s.holding ? '🏗📦' : '🏗'}</span>` : (isCrate ? '📦' : isPud ? '🌊' : isTarget ? '선반' : `${x},${y}`)}
          </div>`;
        }
      }
      stage.innerHTML = `
        <div class="au-board" style="display:grid;grid-template-columns:1fr auto;gap:14px;align-items:start">
          <div style="display:grid;gap:10px">
            <div style="background:#10151B;border:2px solid ${dewOk ? '#52EFBF' : '#7CD8FF'};border-radius:8px;padding:10px">
              <div style="font:800 13px sans-serif;color:${dewOk ? '#52EFBF' : '#7CD8FF'}">① 제습 공조 이슬점 설정 ${dewOk ? '✔ 안개 제거됨' : '(목표 45% RH / 18°C)'}</div>
              <div style="display:flex;gap:8px;margin-top:6px;flex-wrap:wrap">
                <button class="au-btn" id="p10-rhd">-9% RH</button><span style="font:800 13px monospace">${s.rh}% RH</span><button class="au-btn" id="p10-rhu">+9%</button>
              </div>
              <div style="display:flex;gap:8px;margin-top:6px;flex-wrap:wrap">
                <button class="au-btn" id="p10-td">-2°C</button><span style="font:800 13px monospace">${s.temp}°C</span><button class="au-btn" id="p10-tu">+2°C</button>
              </div>
            </div>
            <div style="display:grid;gap:6px">
              <div style="font:800 12px sans-serif;color:#52EFBF">② 2축 호이스트 크레인 조작 (목표: (1,3) 📦 → (4,1) 선반)</div>
              <div style="display:flex;gap:5px;flex-wrap:wrap">
                <button class="au-btn" data-mv="-1,0">◀</button>
                <button class="au-btn" data-mv="0,-1">▲</button>
                <button class="au-btn" data-mv="0,1">▼</button>
                <button class="au-btn" data-mv="1,0">▶</button>
                <button class="au-btn amber" id="p10-hook">${s.holding ? '⬇ 상자 내리기' : '⬆ 상자 집기'}</button>
              </div>
            </div>
          </div>
          <div class="au-grid-5x4">${cells}</div>
        </div>
      `;
      stage.querySelector('#p10-rhd').onclick = () => { s.rh = Math.max(36, s.rh - 9); this.renderModal(); };
      stage.querySelector('#p10-rhu').onclick = () => { s.rh = Math.min(81, s.rh + 9); this.renderModal(); };
      stage.querySelector('#p10-td').onclick = () => { s.temp = Math.max(14, s.temp - 2); this.renderModal(); };
      stage.querySelector('#p10-tu').onclick = () => { s.temp = Math.min(28, s.temp + 2); this.renderModal(); };
      stage.querySelectorAll('[data-mv]').forEach(b => b.onclick = () => {
        const [dx, dy] = b.dataset.mv.split(',').map(Number);
        const nx = Math.max(0, Math.min(4, s.crane[0] + dx));
        const ny = Math.max(1, Math.min(4, s.crane[1] + dy));
        if (s.holding && puddles.has(`${nx},${ny}`)) { this.setErr('침수 물웅덩이 구역 위로는 상자를 지날 수 없습니다!'); return; }
        s.crane = [nx, ny];
        if (s.holding) s.cratePos = [nx, ny];
        this.renderModal();
      });
      stage.querySelector('#p10-hook').onclick = () => {
        if (!s.holding) {
          if (s.crane[0] === s.cratePos[0] && s.crane[1] === s.cratePos[1]) { s.holding = true; this.renderModal(); }
          else this.setErr('크레인을 먼저 상자 📦 위로 이동시킨 후 집어 올리세요.');
        } else {
          s.holding = false;
          if (dewOk && s.cratePos[0] === 4 && s.cratePos[1] === 1) {
            this.markSolved(10, '제습 45%/18°C 안정화 및 스틸 선반(4,1) 방수 상자 안전 안착 완료!');
          } else {
            this.renderModal();
            if (!dewOk) this.setErr('제습 공조 설정을 45% RH / 18°C 로 맞춘 뒤 선반에 내리세요!');
          }
        }
      };
    }

    // P11: Katipunan Baybayin Concentric Decoder Wheel (KA-LA-YA)
    boardP11(stage, p, s) {
      const syls = [
        { k: 'BA', ch: 'ᜊ' }, { k: 'KA', ch: 'ᜃ' }, { k: 'LA', ch: 'ᜎ' }, { k: 'MA', ch: 'ᜋ' }, { k: 'PA', ch: 'ᜉ' }, { k: 'YA', ch: 'ᜌ' },
      ];
      const kudlits = [
        { k: 'up', lbl: '위 점 (i/e)' },
        { k: 'none', lbl: '무점 (기본 a)' },
        { k: 'down', lbl: '아래 점 (u/o)' },
      ];
      const cur = s.slots[s.activeSlot];
      const word = s.slots.map(sl => {
        const vowel = sl.kudlit === 'up' ? 'I' : sl.kudlit === 'down' ? 'U' : 'A';
        return sl.syl[0] + vowel;
      }).join(' - ');
      stage.innerHTML = `
        <div class="au-board" style="display:grid;gap:12px">
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
            ${s.slots.map((sl, i) => {
              const glyph = syls.find(x => x.k === sl.syl)?.ch || '?';
              return `<button class="au-btn ${s.activeSlot === i ? 'primary' : ''}" data-slot="${i}" style="padding:10px">
                <div style="font-size:24px">${glyph}</div>
                <div style="font-size:12px">${i + 1}번째 음절 (${sl.kudlit === 'none' ? sl.syl : sl.syl[0] + (sl.kudlit === 'up' ? 'I' : 'U')})</div>
              </button>`;
            }).join('')}
          </div>
          <div style="background:#10151B;border:2px solid #C89D54;border-radius:8px;padding:12px;display:grid;gap:10px">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px">
              <span style="font:800 13px sans-serif;color:#E6C886">${s.activeSlot + 1}번 칸 내륜 자음 선택:</span>
              <div style="display:flex;gap:5px;flex-wrap:wrap">
                ${syls.map(x => `<button class="au-btn ${cur.syl === x.k ? 'amber' : ''}" data-syl="${x.k}">${x.ch} ${x.k[0]}</button>`).join('')}
              </div>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px">
              <span style="font:800 13px sans-serif;color:#91A8FF">${s.activeSlot + 1}번 칸 외륜 Kudlit 점:</span>
              <div style="display:flex;gap:5px;flex-wrap:wrap">
                ${kudlits.map(x => `<button class="au-btn ${cur.kudlit === x.k ? 'primary' : ''}" data-kud="${x.k}">${x.lbl}</button>`).join('')}
              </div>
            </div>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
            <span style="font:800 14px monospace;color:#FFD86B">실시간 음독: ${word} ${word === 'KA - LA - YA' ? '→ KALAYAAN (자유!)' : ''}</span>
            <button class="au-btn primary" id="p11-check">🔱 비밀 헌장 해독 승인</button>
          </div>
        </div>
      `;
      stage.querySelectorAll('[data-slot]').forEach(b => b.onclick = () => { s.activeSlot = Number(b.dataset.slot); this.renderModal(); });
      stage.querySelectorAll('[data-syl]').forEach(b => b.onclick = () => { s.slots[s.activeSlot].syl = b.dataset.syl; this.renderModal(); });
      stage.querySelectorAll('[data-kud]').forEach(b => b.onclick = () => { s.slots[s.activeSlot].kudlit = b.dataset.kud; this.renderModal(); });
      stage.querySelector('#p11-check').onclick = () => {
        if (word === 'KA - LA - YA') {
          this.markSolved(11, '바이바이인 암호(KA-LA-YA · 자유) 해독 성공! 헌장의 숨은 서명이 복원되었습니다.');
        } else {
          this.setErr(`현재 조합(${word})이 카티푸난 암호 KA - LA - YA (모두 무점)와 다릅니다.`);
        }
      };
    }

    // P12: Microfilm Focus Scanner + 4-Col Punch Card
    boardP12(stage, p, s) {
      const dist = Math.abs(s.fx - 60) + Math.abs(s.fy - 40);
      const blur = Math.min(8, Math.round(dist / 7));
      const sharp = dist <= 12;
      stage.innerHTML = `
        <div class="au-board" style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div style="background:#0F151B;border:2px solid ${sharp ? '#52EFBF' : '#3A4756'};border-radius:8px;padding:10px">
            <div style="font:800 12px sans-serif;color:#52EFBF;margin-bottom:6px">① 마이크로필름 XY 스캐너 (X:${s.fx}, Y:${s.fy})</div>
            <div style="background:#061210;border:2px solid #2A3F3A;padding:12px;border-radius:6px;text-align:center;filter:blur(${blur}px);transition:filter .1s">
              <div style="font:900 14px monospace;color:#52EFBF">TARGET PUNCH CODE</div>
              <div style="font:900 18px monospace;color:#FFD86B;margin-top:4px">COL 2 [★] · COL 4 [🌊]</div>
            </div>
            <div style="margin-top:8px;display:grid;gap:5px">
              <label style="font-size:11px">X 초점 (목표 60): <input type="range" min="0" max="100" step="5" value="${s.fx}" id="p12-fx" style="width:100%"/></label>
              <label style="font-size:11px">Y 초점 (목표 40): <input type="range" min="0" max="100" step="5" value="${s.fy}" id="p12-fy" style="width:100%"/></label>
            </div>
          </div>
          <div style="background:#E6D6B8;border:3px solid #705638;border-radius:8px;padding:10px;color:#1F170F">
            <div style="font:900 13px sans-serif;margin-bottom:6px">② 4열 아카이브 천공 카드 복원기</div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:10px 0">
              ${[0, 1, 2, 3].map(i => `
                <button data-hole="${i}" style="height:74px;border:2px solid #705638;border-radius:6px;background:#FAF0D8;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px">
                  <span style="font:900 12px monospace">${i + 1}열</span>
                  <span style="width:22px;height:22px;border-radius:50%;border:2px solid #1F170F;background:${s.holes[i] ? '#1F170F' : 'transparent'}"></span>
                  <span style="font-size:11px">${i === 1 ? '★' : i === 3 ? '🌊' : i === 0 ? '☀' : '⛰'}</span>
                </button>
              `).join('')}
            </div>
            <button class="au-btn primary" style="width:100%" id="p12-stamp">🔖 천공 카드 ARCHIVED 스탬프</button>
          </div>
        </div>
      `;
      stage.querySelector('#p12-fx').oninput = (e) => { s.fx = Number(e.target.value); this.renderModal(); };
      stage.querySelector('#p12-fy').oninput = (e) => { s.fy = Number(e.target.value); this.renderModal(); };
      stage.querySelectorAll('[data-hole]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.hole); s.holes[i] = !s.holes[i]; this.renderModal();
      });
      stage.querySelector('#p12-stamp').onclick = () => {
        const ok = !s.holes[0] && s.holes[1] && !s.holes[2] && s.holes[3];
        if (ok) {
          s.stamped = true;
          this.markSolved(12, '마이크로필름 좌표(2열 ★ · 4열 🌊) 천공 복원 & 스탬프 완료!');
        } else {
          this.setErr('잘못 타공된 열이 있습니다! 다시 클릭해 보수 테이프로 막고 2열과 4열만 뚫으세요.');
        }
      };
    }

    // P13: 3-Color Dropper pH 7.0 Titration + Ultrasonic Brush Scrub Canvas
    boardP13(stage, p, s) {
      const ph = Number((7.0 - s.cyan * 1.1 + s.amber * 2.2).toFixed(1));
      const phOk = s.cyan === 2 && s.amber === 1;
      const doneCnt = s.scrubGrid.filter(Boolean).length;
      const pct = Math.round((doneCnt / s.scrubGrid.length) * 100);
      stage.innerHTML = `
        <div class="au-board" style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div style="background:#10151B;border:2px solid ${phOk ? '#52EFBF' : '#3A4756'};border-radius:8px;padding:10px">
            <div style="font:800 13px sans-serif;color:${phOk ? '#52EFBF' : '#7CD8FF'}">① 3색 시약 스포이드 적정 (목표 pH 7.0)</div>
            <div style="margin:10px 0;padding:10px;background:#091015;border-radius:6px;text-align:center">
              <div style="font:900 22px monospace;color:${ph === 7.0 && phOk ? '#52EFBF' : '#FFB86B'}">pH ${ph.toFixed(1)}</div>
              <div style="font-size:11px;color:#9AA7B4">청록 ${s.cyan}방울 · 호박 ${s.amber}방울</div>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <button class="au-btn" id="p13-cyan" style="border-color:#7CD8FF">🧪 청록 +1</button>
              <button class="au-btn" id="p13-amber" style="border-color:#E6C886">🧪 호박 +1</button>
              <button class="au-btn danger" id="p13-rinse">💧 증류수 헹굼</button>
            </div>
          </div>
          <div style="background:#10151B;border:2px solid ${pct >= 90 ? '#52EFBF' : '#C89D54'};border-radius:8px;padding:10px">
            <div style="font:800 13px sans-serif;color:#E6C886;margin-bottom:6px">② 초음파 브러시 부식층 세척 (${pct}% · 타일 위를 드래그!)</div>
            <div id="p13-scrub" style="display:grid;grid-template-columns:repeat(6,1fr);gap:2px;background:#C89D54;padding:6px;border-radius:6px;user-select:none">
              ${s.scrubGrid.map((c, i) => `<div data-sc="${i}" style="height:26px;border-radius:3px;cursor:crosshair;background:${c ? 'rgba(255,228,150,0.22)' : '#2F7D63'};border:1px solid #0B0E13"></div>`).join('')}
            </div>
            <button class="au-btn primary" style="width:100%;margin-top:8px" id="p13-done">✨ 청동 광택 검수 완료</button>
          </div>
        </div>
      `;
      stage.querySelector('#p13-cyan').onclick = () => { s.cyan = Math.min(5, s.cyan + 1); this.renderModal(); };
      stage.querySelector('#p13-amber').onclick = () => { s.amber = Math.min(5, s.amber + 1); this.renderModal(); };
      stage.querySelector('#p13-rinse').onclick = () => { s.cyan = 0; s.amber = 0; this.renderModal(); };
      const scrubBox = stage.querySelector('#p13-scrub');
      const paintCell = (el) => {
        if (!el || !el.dataset.sc) return;
        const idx = Number(el.dataset.sc);
        if (!s.scrubGrid[idx]) {
          s.scrubGrid[idx] = true;
          el.style.background = 'rgba(255,228,150,0.22)';
          const done = s.scrubGrid.filter(Boolean).length;
          const label = stage.querySelector('[style*="초음파 브러시"]');
          if (label) label.textContent = `② 초음파 브러시 부식층 세척 (${Math.round(done / 24 * 100)}% · 타일 위를 드래그!)`;
        }
      };
      scrubBox.addEventListener('pointerdown', (e) => { this._scrubbing = true; paintCell(e.target); });
      window.addEventListener('pointerup', () => { this._scrubbing = false; }, { once: true });
      scrubBox.addEventListener('pointermove', (e) => { if (this._scrubbing) paintCell(e.target); });
      scrubBox.querySelectorAll('[data-sc]').forEach(d => d.onclick = () => paintCell(d));
      stage.querySelector('#p13-done').onclick = () => {
        const donePct = Math.round(s.scrubGrid.filter(Boolean).length / 24 * 100);
        if (phOk && donePct >= 88) {
          this.markSolved(13, 'pH 7.0 시약 중화 및 청동 유물 초음파 세척 복원 완료!');
        } else {
          this.setErr(`시약(${s.cyan} 청록 / ${s.amber} 호박 → 목표 2:1) 또는 세척률(${donePct}% → 90% 이상)이 부족합니다.`);
        }
      };
    }

    // P14: 4-Corner Diagonal Pulley Rope Tension + Wax Seal Mold
    boardP14(stage, p, s) {
      const ropeDone = s.rope.every(v => v === 0);
      const sealOk = s.waxRot.every(r => r % 360 === 0);
      stage.innerHTML = `
        <div class="au-board" style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div style="background:#10151B;border:2px solid ${ropeDone ? '#52EFBF' : '#C89D54'};border-radius:8px;padding:10px">
            <div style="font:800 13px sans-serif;color:#E6C886;margin-bottom:6px">① 4점 도르래 대각선 이완 (①→③ 먼저, 그다음 ②→④)</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
              ${[0, 1, 3, 2].map(i => `
                <div style="background:#1B242E;border:2px solid ${s.rope[i] === 0 ? '#52EFBF' : '#0B0E13'};border-radius:6px;padding:8px;text-align:center">
                  <div style="font:800 12px monospace">모서리 #${i + 1}: ${s.rope[i]}%</div>
                  <button class="au-btn" style="margin-top:5px;padding:4px 10px" data-rl="${i}" ${s.rope[i] === 0 ? 'disabled' : ''}>장력 0% 풀기</button>
                </div>
              `).join('')}
            </div>
          </div>
          <div style="background:#10151B;border:2px solid ${ropeDone ? '#52EFBF' : '#3A4756'};border-radius:8px;padding:10px">
            <div style="font:800 13px sans-serif;color:#FF8E8E;margin-bottom:6px">② 깨진 붉은 밀랍 봉인 3조각 정렬 &amp; 압착</div>
            <div style="display:flex;gap:8px;justify-content:center;margin:10px 0">
              ${s.waxRot.map((r, i) => `
                <button class="au-btn ${r % 360 === 0 ? 'primary' : ''}" data-wx="${i}" ${!ropeDone ? 'disabled style="opacity:.4"' : ''}>
                  조각 ${i + 1}<br><strong>${r}°</strong>
                </button>
              `).join('')}
            </div>
            <button class="au-btn primary" style="width:100%" id="p14-press">🔏 황동 인장 프레스 압착</button>
          </div>
        </div>
      `;
      stage.querySelectorAll('[data-rl]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.rl);
        // Check diagonal sequence: 1 (idx 0) & 3 (idx 2) must be loosened before 2 (idx 1) & 4 (idx 3)
        if ((i === 1 || i === 3) && (s.rope[0] > 0 || s.rope[2] > 0)) {
          this.setErr('대각선 균형 경고! 먼저 ①(좌상)과 ③(우하) 대각선 로프를 0%로 풀어야 상자가 뒤틀리지 않습니다.');
          return;
        }
        s.rope[i] = 0;
        this.setInfo(`모서리 #${i + 1} 도르래 안전 이완!`);
      });
      stage.querySelectorAll('[data-wx]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.wx); s.waxRot[i] = (s.waxRot[i] + 90) % 360; this.renderModal();
      });
      stage.querySelector('#p14-press').onclick = () => {
        if (!ropeDone) { this.setErr('먼저 4모서리 도르래를 모두 0%로 이완해 상자를 여세요.'); return; }
        if (sealOk) {
          s.pressed = true;
          this.markSolved(14, '4점 대각선 이완 및 밀랍 봉인 압착 복원 완료!');
        } else {
          this.setErr('밀랍 3조각의 각도를 모두 0° 정방향으로 회전해 맞춘 뒤 압착하세요.');
        }
      };
    }

    // P15: Translucent Blueprint Tracing Paper Overlay
    boardP15(stage, p, s) {
      const dist = Math.hypot(s.ox, s.oy);
      const rotOk = s.rot % 360 === 0;
      const closeEnough = dist <= 12 && rotOk;
      stage.innerHTML = `
        <div class="au-board" style="display:grid;gap:10px">
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
            <span style="font:800 13px sans-serif;color:#E6C886">반투명 성곽 도면 트레이싱지 (마우스로 드래그 또는 화살표 이동 + 회전 0° 일치)</span>
            <div style="display:flex;gap:5px">
              <button class="au-btn" id="p15-rotl">↺ -90°</button>
              <button class="au-btn" id="p15-rotr">↻ +90°</button>
              <span style="font:800 12px monospace;padding:6px 8px;background:#10151B;border-radius:5px">(${Math.round(s.ox)}, ${Math.round(s.oy)}) · ${s.rot}°</span>
            </div>
          </div>
          <svg id="p15-svg" viewBox="0 0 420 200" style="width:100%;height:200px;background:#1A222B;border:3px solid #0B0E13;border-radius:8px;cursor:grab;touch-action:none">
            <circle cx="110" cy="60" r="9" fill="none" stroke="${closeEnough ? '#52EFBF' : '#FFB86B'}" stroke-width="3"/>
            <circle cx="310" cy="70" r="9" fill="none" stroke="${closeEnough ? '#52EFBF' : '#FFB86B'}" stroke-width="3"/>
            <circle cx="210" cy="150" r="9" fill="none" stroke="${closeEnough ? '#52EFBF' : '#FFB86B'}" stroke-width="3"/>
            <text x="110" y="45" text-anchor="middle" fill="#D5DFE8" font-size="10">Puerta Real</text>
            <text x="310" y="55" text-anchor="middle" fill="#D5DFE8" font-size="10">Fort Santiago</text>
            <text x="210" y="172" text-anchor="middle" fill="#D5DFE8" font-size="10">Baluarte</text>
            <g transform="translate(${s.ox} ${s.oy}) rotate(${s.rot} 210 100)" opacity="0.82">
              <rect x="65" y="25" width="290" height="150" rx="6" fill="rgba(230,214,184,0.18)" stroke="#E6D6B8" stroke-width="2" stroke-dasharray="6 4"/>
              <circle cx="110" cy="60" r="5" fill="#52EFBF"/>
              <circle cx="310" cy="70" r="5" fill="#52EFBF"/>
              <circle cx="210" cy="150" r="5" fill="#52EFBF"/>
              <polygon points="110,60 310,70 210,150" fill="rgba(82,239,191,0.12)" stroke="#52EFBF" stroke-width="2"/>
            </g>
          </svg>
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px">
            <div style="display:flex;gap:5px">
              <button class="au-btn" data-nudge="-16,0">← 서</button>
              <button class="au-btn" data-nudge="0,-16">↑ 북</button>
              <button class="au-btn" data-nudge="0,16">↓ 남</button>
              <button class="au-btn" data-nudge="16,0">→ 동</button>
            </div>
            <button class="au-btn primary" id="p15-lock">📐 3개 성곽 앵커 포개기 확정</button>
          </div>
        </div>
      `;
      const svg = stage.querySelector('#p15-svg');
      let dragging = false, sx = 0, sy = 0, ox0 = 0, oy0 = 0;
      svg.onpointerdown = (e) => {
        dragging = true; svg.setPointerCapture(e.pointerId);
        sx = e.clientX; sy = e.clientY; ox0 = s.ox; oy0 = s.oy;
      };
      svg.onpointermove = (e) => {
        if (!dragging) return;
        s.ox = Math.max(-140, Math.min(140, ox0 + (e.clientX - sx)));
        s.oy = Math.max(-90, Math.min(90, oy0 + (e.clientY - sy)));
        const g = svg.querySelector('g');
        if (g) g.setAttribute('transform', `translate(${s.ox} ${s.oy}) rotate(${s.rot} 210 100)`);
      };
      svg.onpointerup = () => { if (dragging) { dragging = false; this.renderModal(); } };
      stage.querySelector('#p15-rotl').onclick = () => { s.rot = (s.rot + 270) % 360; this.renderModal(); };
      stage.querySelector('#p15-rotr').onclick = () => { s.rot = (s.rot + 90) % 360; this.renderModal(); };
      stage.querySelectorAll('[data-nudge]').forEach(b => b.onclick = () => {
        const [dx, dy] = b.dataset.nudge.split(',').map(Number); s.ox += dx; s.oy += dy; this.renderModal();
      });
      stage.querySelector('#p15-lock').onclick = () => {
        if (closeEnough) { s.ox = 0; s.oy = 0; this.markSolved(15, '성곽 건축 도면 트레이싱 오버레이 3점 정밀 일치 완료!'); }
        else this.setErr(`회전(${s.rot}°→0°)과 좌표(${Math.round(s.ox)}, ${Math.round(s.oy)} → ±12px 이내)를 3개 앵커 핀 위로 더 가까이 맞추세요.`);
      };
    }

    // P16: Optical Prisms (Stage 1) + Atrium 4/4 Medallion Convergence Finale (Stage 2)
    boardP16(stage, p, s) {
      const targetPrisms = [45, 135, 90];
      const beamOk = s.prisms[0] === 45 && s.prisms[1] === 135 && s.prisms[2] === 90;
      if (beamOk) s.beamOk = true;
      const padsCnt = s.pads.filter(Boolean).length;
      stage.innerHTML = `
        <div class="au-board" style="display:grid;gap:12px">
          <div style="background:#0F151B;border:2px solid ${beamOk ? '#52EFBF' : '#FFB86B'};border-radius:8px;padding:10px">
            <div style="font:800 13px sans-serif;color:${beamOk ? '#52EFBF' : '#FFD86B'};margin-bottom:6px">1부 · 기획전시실 3프리즘 광학 굴절 (목표: M1=45°, M2=135°, M3=90° 동→ 반원 홀)</div>
            <svg viewBox="0 0 420 115" style="width:100%;height:110px;background:#090E12;border:2px solid #23303B;border-radius:6px">
              <line x1="15" y1="30" x2="110" y2="30" stroke="#FFD86B" stroke-width="4"/>
              <line x1="110" y1="30" x2="${s.prisms[0] === 45 ? 110 : 195}" y2="${s.prisms[0] === 45 ? 85 : 30}" stroke="#FFD86B" stroke-width="4" opacity="${s.prisms[0] === 45 ? 1 : 0.35}"/>
              ${s.prisms[0] === 45 ? `<line x1="110" y1="85" x2="${s.prisms[1] === 135 ? 310 : 210}" y2="85" stroke="#52EFBF" stroke-width="4"/>` : ''}
              ${beamOk ? `<line x1="310" y1="85" x2="310" y2="14" stroke="#7CD8FF" stroke-width="5"/><circle cx="310" cy="14" r="6" fill="#52EFBF"/>` : ''}
              <rect x="92" y="18" width="36" height="24" rx="4" fill="#1C2936" stroke="#7CD8FF" stroke-width="2"/><text x="110" y="34" text-anchor="middle" fill="#fff" font-size="9">M1:${s.prisms[0]}°</text>
              <rect x="92" y="72" width="36" height="24" rx="4" fill="#1C2936" stroke="#7CD8FF" stroke-width="2"/><text x="110" y="88" text-anchor="middle" fill="#fff" font-size="9">M2:${s.prisms[1]}°</text>
              <rect x="292" y="72" width="36" height="24" rx="4" fill="#1C2936" stroke="#7CD8FF" stroke-width="2"/><text x="310" y="88" text-anchor="middle" fill="#fff" font-size="9">M3:${s.prisms[2]}°</text>
              <text x="372" y="20" text-anchor="middle" fill="${beamOk ? '#52EFBF' : '#889'}" font-size="10">↑ 2F 반원 홀 여신상</text>
            </svg>
            <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
              ${[0, 1, 2].map(i => `<button class="au-btn ${s.prisms[i] === targetPrisms[i] ? 'primary' : ''}" data-pr="${i}">프리즘 M${i + 1} 회전 (${s.prisms[i]}°)</button>`).join('')}
            </div>
          </div>
          <div style="background:#10151B;border:2px solid ${padsCnt === 4 && s.hereSent ? '#52EFBF' : '#394654'};border-radius:8px;padding:10px">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:8px">
              <strong style="color:#E6C886">2부 · 반원 동상 홀 4인 문장 발판 집결 (${padsCnt}/4 · gather-1~4)</strong>
              <div style="display:flex;gap:6px">
                <button class="au-btn amber" id="p16-here">📍 [집결 호출 HERE] 무전</button>
                <button class="au-btn" id="p16-goto-atrium">🏃 2F 반원 홀 맵으로 이동</button>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">
              ${['doyun', 'maria', 'lin', 'aisha'].map((rid, i) => {
                const rr = ROLES[rid];
                return `<button class="au-btn ${s.pads[i] ? 'primary' : ''}" data-pad="${i}" style="border-color:${rr.color}">
                  ${rr.badge} ${rr.name}<br><small>${s.pads[i] ? '✔ 발판 착지' : `gather-${i + 1}`}</small>
                </button>`;
              }).join('')}
            </div>
            <button class="au-btn primary" style="width:100%;margin-top:8px" id="p16-finale">👑 박물관 전체 정식 개관 대관식 실행!</button>
          </div>
        </div>
      `;
      stage.querySelectorAll('[data-pr]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.pr); s.prisms[i] = (s.prisms[i] + 45) % 180; this.renderModal();
      });
      stage.querySelector('#p16-here').onclick = () => {
        this.sendRadio('lin', ['COOP_HERE']);
        this.setInfo('린이 C-Menu [집결 호출 HERE]를 전 층에 발신했습니다!');
      };
      stage.querySelector('#p16-goto-atrium').onclick = () => {
        const atriumPad = getPuzzleObjects(16).find(o => o.id === 'gather-1');
        if (atriumPad && this.host?.onJumpToObject) {
          this.host.onJumpToObject(atriumPad);
          this.closeModal();
        }
      };
      stage.querySelectorAll('[data-pad]').forEach(b => b.onclick = () => {
        const i = Number(b.dataset.pad); s.pads[i] = !s.pads[i]; this.renderModal();
      });
      stage.querySelector('#p16-finale').onclick = () => {
        if (beamOk && s.hereSent && padsCnt === 4) {
          this.markSolved(16, '16/16 대관식 엔딩 달성! 1층·지하·2층의 모든 빛이 반원 홀 여신상 위로 합쳐졌습니다!');
        } else {
          this.setErr(`1부 프리즘 정렬(${beamOk ? 'OK' : '45°·135°·90° 필요'}), [집결 호출 HERE](${s.hereSent ? 'OK' : '미발신'}), 발판(${padsCnt}/4)을 모두 완료하세요.`);
        }
      };
    }
  }

  window.StrangerPuzzleDemo = StrangerPuzzleDemo;
  window.STRANGER_PUZZLES = PUZZLES;
  window.STRANGER_ROLES = ROLES;
  window.STRANGER_GET_PUZZLE_OBJECTS = getPuzzleObjects;
})();
